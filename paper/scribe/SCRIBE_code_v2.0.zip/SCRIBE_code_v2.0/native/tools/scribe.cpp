// SCRIBE: the generated-text metric (docs/PLAN.md section 6). One tool for every use; it replaces
// scribe_ladder.cpp (v0 and v1). Library: native/include/cypha/eval/scribe.hpp (header-only, no neural network).
// Reports: docs/reports/SCRIBE_V0.md, SCRIBE_V1.md, SCRIBE_V2.md, SCRIBE_V3.md, SCRIBE_V31.md. Plan of the v2 study: docs/SCRIBE_PAPER_PLAN.md.
//
// SCRIBE v3.1 (--profile v31 for ladder, score and attacks; docs/reports/SCRIBE_V31.md): the geometric mean of v2,
// SURPRISE 3.1 and MATCH 3.1, so one judge's confident catch is not diluted; the v3 judges are scored next to it.
// attacks --heldout adds v3.1's held-out attacks (read once, on fresh data only). ladder / attacks --dedup drop test
// documents that are near-duplicates of pack or reference documents; `dedup` only counts them.
//
// Subcommands
//   docs     SRC --out F                                    cleaned documents, one JSON object per line
//   prompts  SRC --n 250 --seed S --set NAME [--per-doc K] --out F
//                                                           prompt (100-300 B) + true human continuation (400-600 B,
//                                                           >= 3 sentences), one per document (K > 1: up to K consecutive)
//   samples  SRC --n 500 --seed S --set NAME [--short] [--system NAME] --out F
//                                                           samples cut from documents the way human samples are
//                                                           (sentence windows of 400-600 B with >= 3 sentences, or 60-260 B)
//   prepare  --in F --out G [--mode continuation|wikiraw|plain] [--min-bytes 100]
//                                                           model output -> the text that is scored (and that every
//                                                           baseline scores): continuation = whitespace collapsed and the
//                                                           unterminated tail cut; wikiraw = v1's clean_generated_text
//   ladder   --pack SRC --ref SRC --test SRC [--vectors P] [--profile v1|v2|v3|v31] [--seed S] [--chain-rng]
//            [--gen-trie F] [--model F]... [--export DIR] [--label L] [--dedup]
//                                                           the PLAN 6.4 V1 control ladder (and model rungs), report on stdout;
//                                                           --profile v3 adds the table of v2, SURPRISE, MATCH, their mean (v3)
//                                                           and minimum for every rung and pair (docs/reports/SCRIBE_V3.md);
//                                                           v31 adds SURPRISE 3.1, MATCH 3.1 and v3.1
//   attacks  --pack SRC --ref SRC --test SRC --vectors P [--profile v3|v31] [--seed S] [--n 200] [--outside SRC]
//            [--export DIR] [--heldout] [--dedup]
//                                                           v3's attack battery on prompt / continuation pairs of SRC: every
//                                                           attack x metric, and the registered rule (exit 3 if it fails)
//   dedup    --pack SRC --ref SRC --test SRC                how many test documents --dedup would drop (scores nothing)
//   score    --pack SRC --ref SRC [--vectors P] [--profile v1|v2|v3|v31] [--v2 PARAMS] [--v3 PARAMS] [--ref-prompts F] --in F --out G
//                                                           every text of F scored: axes, sub-scores, raw statistics; a text
//                                                           with a "prompt" also gets the relevance statistics (R, scored
//                                                           against --ref-prompts, and counted in D only with wR > 0).
//                                                           --window: a long text scores the mean over its sentence windows
//                                                           of 300-600 B; --ref-whole: reference documents are samples as
//                                                           they are (short whole texts such as ROC stories). With --profile
//                                                           v3 the headline "scribe" is scribe_v3 = mean(scribe_v2, surprise,
//                                                           match), and min3 / disagree are added; MATCH's echo uses "prompt"
//   windows  --in F --out G                                 each text cut into its --window scoring windows (prompt kept)
//   selftest                                                known-answer checks (CTest native_scribe_selftest)
//
// SRC is enwik:PATH:LO:HI (bytes [LO, HI) MiB of a MediaWiki XML dump such as enwik8/enwik9, cleaned page by page
// with clean_wiki_documents, as v0 and v1 did), a JSONL file whose "text" fields are documents (cleaned with
// clean_plain_document: prose lines only), or raw:PATH (JSONL documents used as they are, white space collapsed). JSONL lines in and out: {"id", "set", "system", "text", "prompt"?, "ref"?}.
//
// v1 parity: `ladder --pack enwik:E:16:48 --ref enwik:E:48:56 --test enwik:E:56:64 --vectors v32 --profile v1
// --seed 20261027 --chain-rng --gen-trie gen_dev.txt` prints the v1 development ladder's rung means and pair verdicts to
// the printed digit, and `--test enwik:E:64:72 --seed 31415926 --gen-trie gen_fresh.txt` the v1 fresh ladder.
//
// Author: Odin Loch

#include "cypha/eval/scribe.hpp"

#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>

using namespace cypha::eval;
using cypha::eval::scribe_detail::is_alpha_a;
using cypha::eval::scribe_detail::is_digit_a;
using cypha::eval::scribe_detail::is_space_a;
using cypha::eval::scribe_detail::is_upper_a;

namespace {

constexpr std::size_t MiB = 1048576;

double now_s() {
  using namespace std::chrono;
  return duration<double>(steady_clock::now().time_since_epoch()).count();
}
double g_t0 = now_s();
// Profiling counters (printed with --timing): seconds in extract_features (v1 statistics, sentence vectors) and in
// ScribeV2Scorer::extend (skeleton, word rarity, 8-gram copy, relevance), and the number of texts featurised.
double g_t_extract = 0, g_t_extend = 0, g_t_pack_model = 0, g_t_pack_v2 = 0, g_t_pack_vec = 0, g_t_v3 = 0;
std::size_t g_n_feat = 0;
std::string g_dedup_note;  // set by --dedup (near_duplicates), printed under a report's title


// ===========================================================================
// JSON lines: a small reader for flat objects (nested values are skipped) and a writer
// ===========================================================================

std::string json_escape(const std::string& s) {
  std::string o;
  o.reserve(s.size() + 16);
  for (std::size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    if (c >= 0x80) {
      const std::size_t L = scribe_detail::utf8_seq_len(s, i);
      if (L == 0) {
        o += "\\ufffd";  // invalid byte: replacement character, so every reader accepts the line
        ++i;
      } else {
        o.append(s, i, L);
        i += L;
      }
      continue;
    }
    switch (c) {
      case '"': o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n"; break;
      case '\r': o += "\\r"; break;
      case '\t': o += "\\t"; break;
      default:
        if (c < 0x20) {
          char b[8];
          std::snprintf(b, sizeof b, "\\u%04x", c);
          o += b;
        } else {
          o.push_back(static_cast<char>(c));
        }
    }
    ++i;
  }
  return o;
}

struct JsonObj {
  std::map<std::string, std::string> str;  // top-level string values
  std::map<std::string, double> num;       // top-level numbers
  std::string get(const std::string& k, const std::string& def = "") const {
    const auto it = str.find(k);
    return it == str.end() ? def : it->second;
  }
};

class JsonReader {
 public:
  explicit JsonReader(const std::string& s) : s_(s) {}
  bool object(JsonObj& o) {
    ws();
    if (!eat('{')) return false;
    ws();
    if (eat('}')) return true;
    while (true) {
      ws();
      std::string k;
      if (!string(k)) return false;
      ws();
      if (!eat(':')) return false;
      ws();
      if (peek() == '"') {
        std::string v;
        if (!string(v)) return false;
        o.str[k] = std::move(v);
      } else if (peek() == '{' || peek() == '[') {
        if (!skip_nested()) return false;
      } else {
        const std::size_t b = p_;
        while (p_ < s_.size() && s_[p_] != ',' && s_[p_] != '}' && !is_space_a(static_cast<unsigned char>(s_[p_]))) ++p_;
        const std::string tok = s_.substr(b, p_ - b);
        char* end = nullptr;
        const double v = std::strtod(tok.c_str(), &end);
        if (end && *end == '\0' && !tok.empty()) o.num[k] = v;
      }
      ws();
      if (eat(',')) continue;
      if (eat('}')) return true;
      return false;
    }
  }

 private:
  char peek() const { return p_ < s_.size() ? s_[p_] : '\0'; }
  bool eat(char c) {
    if (peek() != c) return false;
    ++p_;
    return true;
  }
  void ws() {
    while (p_ < s_.size() && is_space_a(static_cast<unsigned char>(s_[p_]))) ++p_;
  }
  static int hexv(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
  }
  bool hex4(unsigned& v) {
    if (p_ + 4 > s_.size()) return false;
    v = 0;
    for (int k = 0; k < 4; ++k) {
      const int h = hexv(s_[p_ + static_cast<std::size_t>(k)]);
      if (h < 0) return false;
      v = v * 16 + static_cast<unsigned>(h);
    }
    p_ += 4;
    return true;
  }
  bool string(std::string& out) {
    if (!eat('"')) return false;
    while (p_ < s_.size()) {
      const char c = s_[p_++];
      if (c == '"') return true;
      if (c != '\\') {
        out.push_back(c);
        continue;
      }
      if (p_ >= s_.size()) return false;
      const char e = s_[p_++];
      switch (e) {
        case 'n': out.push_back('\n'); break;
        case 't': out.push_back('\t'); break;
        case 'r': out.push_back('\r'); break;
        case 'b': out.push_back('\b'); break;
        case 'f': out.push_back('\f'); break;
        case 'u': {
          unsigned cp = 0;
          if (!hex4(cp)) return false;
          if (cp >= 0xD800 && cp <= 0xDBFF && p_ + 6 <= s_.size() && s_[p_] == '\\' && s_[p_ + 1] == 'u') {
            const std::size_t at = p_;
            p_ += 2;
            unsigned lo = 0;
            if (!hex4(lo)) return false;
            if (lo >= 0xDC00 && lo <= 0xDFFF) {
              cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
            } else {  // a lone high surrogate: replace it, and read the next escape on its own
              cp = 0xFFFD;
              p_ = at;
            }
          } else if (cp >= 0xD800 && cp <= 0xDFFF) {
            cp = 0xFFFD;
          }
          scribe_detail::append_utf8(out, cp);
          break;
        }
        default: out.push_back(e);  // \" \\ \/
      }
    }
    return false;
  }
  bool skip_nested() {
    int depth = 0;
    while (p_ < s_.size()) {
      const char c = s_[p_];
      if (c == '"') {
        std::string tmp;
        if (!string(tmp)) return false;
        continue;
      }
      ++p_;
      if (c == '{' || c == '[') ++depth;
      else if (c == '}' || c == ']') {
        if (--depth == 0) return true;
      }
    }
    return false;
  }
  const std::string& s_;
  std::size_t p_ = 0;
};

std::vector<JsonObj> read_jsonl(const std::string& path) {
  std::vector<JsonObj> v;
  std::ifstream in(path);
  if (!in) {
    std::fprintf(stderr, "cannot open %s\n", path.c_str());
    std::exit(1);
  }
  std::string line;
  std::size_t ln = 0, bad = 0;
  while (std::getline(in, line)) {
    ++ln;
    if (line.empty()) continue;
    JsonObj o;
    if (JsonReader(line).object(o)) v.push_back(std::move(o));
    else ++bad;
  }
  if (bad) std::fprintf(stderr, "%s: %zu of %zu lines are not JSON objects (skipped)\n", path.c_str(), bad, ln);
  return v;
}

// One output line: {"id":..,"set":..,"system":..,"text":..[,"prompt":..][,"ref":..]} plus raw extra JSON members.
std::string text_line(const std::string& id, const std::string& set, const std::string& system, const std::string& text,
                      const std::string& prompt = "", const std::string& ref = "", const std::string& extra = "") {
  std::string o = "{\"id\":\"" + json_escape(id) + "\",\"set\":\"" + json_escape(set) + "\",\"system\":\"" + json_escape(system) +
                  "\",\"text\":\"" + json_escape(text) + "\"";
  if (!prompt.empty()) o += ",\"prompt\":\"" + json_escape(prompt) + "\"";
  if (!ref.empty()) o += ",\"ref\":\"" + json_escape(ref) + "\"";
  if (!extra.empty()) o += "," + extra;
  o += "}";
  return o;
}

std::string num(double v, int prec = 6) {
  if (!std::isfinite(v)) return "null";
  char b[64];
  std::snprintf(b, sizeof b, "%.*g", prec, v);
  return b;
}

// ===========================================================================
// Sources and samples
// ===========================================================================

// enwik:PATH:LO:HI -> cleaned pages of bytes [LO, HI) MiB; anything else -> JSONL documents (clean_plain_document).
std::vector<std::string> load_docs(const std::string& spec) {
  if (spec.rfind("enwik:", 0) == 0) {
    const std::size_t c2 = spec.rfind(':'), c1 = spec.rfind(':', c2 - 1);
    if (c1 == std::string::npos || c1 < 6) {
      std::fprintf(stderr, "bad source %s (want enwik:PATH:LO:HI)\n", spec.c_str());
      std::exit(2);
    }
    const std::string path = spec.substr(6, c1 - 6);
    const double lo = std::strtod(spec.c_str() + c1 + 1, nullptr), hi = std::strtod(spec.c_str() + c2 + 1, nullptr);
    std::ifstream in(path, std::ios::binary);
    if (!in) {
      std::fprintf(stderr, "cannot open %s\n", path.c_str());
      std::exit(1);
    }
    in.seekg(0, std::ios::end);
    const std::streamoff end = in.tellg();
    if (!in || end < 0) {
      std::fprintf(stderr, "cannot read %s (not a regular file?)\n", path.c_str());
      std::exit(1);
    }
    const std::size_t size = static_cast<std::size_t>(end);
    const std::size_t b = std::min(size, static_cast<std::size_t>(lo * MiB)), e = std::min(size, static_cast<std::size_t>(hi * MiB));
    std::vector<char> raw(e > b ? e - b : 0);
    in.seekg(static_cast<std::streamoff>(b));
    in.read(raw.data(), static_cast<std::streamsize>(raw.size()));
    if (!in) {
      std::fprintf(stderr, "cannot read %s bytes [%zu, %zu)\n", path.c_str(), b, e);
      std::exit(1);
    }
    return clean_wiki_documents(raw.data(), raw.size());
  }
  // raw:PATH = JSONL documents used as they are (white space collapsed), for sets that are already one-line,
  // lowercased or tokenised (ROCStories, OpenMEVA); the pack, the reference and the scored texts then all match.
  const bool raw = spec.rfind("raw:", 0) == 0;
  std::vector<std::string> docs;
  for (const JsonObj& o : read_jsonl(raw ? spec.substr(4) : spec)) {
    std::string d = raw ? scribe_detail::collapse_ws(collapse_newlines(o.get("text"))) : clean_plain_document(o.get("text"));
    if (!d.empty()) docs.push_back(std::move(d));
  }
  return docs;
}

struct Sample {
  std::string text;
  int doc = 0;
};

// Fresh-data hygiene (SCRIBE v3.1, docs/reports/SCRIBE_V31.md): enwik9 holds some pages more than once, so a test
// document can repeat a pack or reference document. A test document is a near-duplicate when more than half of its
// bytes lie inside matches of the full 64 bytes (PackIndex::kCap) with the pack's or the reference's text. Returns one
// flag per document; *bytes_dropped counts their bytes.
std::vector<char> near_duplicates(const std::vector<std::string>& docs, const std::vector<std::string>& pack_docs,
                                  const std::vector<std::string>& ref_docs, std::size_t* bytes_dropped = nullptr) {
  std::vector<std::string> all(pack_docs);
  all.insert(all.end(), ref_docs.begin(), ref_docs.end());
  PackIndex px;
  px.build(all, 4);
  std::vector<char> dup(docs.size(), 0);
  std::atomic<std::size_t> next{0};
  auto work = [&]() {
    for (std::size_t d; (d = next++) < docs.size();) {
      const std::string& t = docs[d];
      const std::size_t n = t.size();
      if (n == 0) continue;
      std::vector<char> cov(n, 0);
      const unsigned char* p = reinterpret_cast<const unsigned char*>(t.data());
      for (std::size_t i = 0; i + PackIndex::kCap <= n; ++i)
        if (px.match(p + i, n - i) >= PackIndex::kCap) std::fill(cov.begin() + static_cast<std::ptrdiff_t>(i), cov.begin() + static_cast<std::ptrdiff_t>(i + PackIndex::kCap), 1);
      std::size_t c = 0;
      for (char x : cov) c += static_cast<std::size_t>(x);
      dup[d] = 2 * c > n;
    }
  };
  std::vector<std::thread> th;
  for (int k = 1; k < 4; ++k) th.emplace_back(work);
  work();
  for (std::thread& x : th) x.join();
  if (bytes_dropped) {
    *bytes_dropped = 0;
    for (std::size_t d = 0; d < docs.size(); ++d)
      if (dup[d]) *bytes_dropped += docs[d].size();
  }
  return dup;
}

// --dedup: drops the near-duplicate test documents and says how many it dropped (stderr, and the report's header).
std::string apply_dedup(std::vector<std::string>& test_docs, const std::vector<std::string>& pack_docs, const std::vector<std::string>& ref_docs) {
  std::size_t bytes = 0, total = 0;
  for (const std::string& d : test_docs) total += d.size();
  const std::vector<char> dup = near_duplicates(test_docs, pack_docs, ref_docs, &bytes);
  std::vector<std::string> kept;
  for (std::size_t d = 0; d < test_docs.size(); ++d)
    if (!dup[d]) kept.push_back(std::move(test_docs[d]));
  char b[512];
  std::snprintf(b, sizeof b, "Near-duplicate filter (--dedup): dropped %zu of %zu test documents (%zu of %zu bytes) with more than half their bytes inside 64-byte "
                "matches with the pack or the reference.",
                test_docs.size() - kept.size(), test_docs.size(), bytes, total);
  test_docs = std::move(kept);
  std::fprintf(stderr, "%s\n", b);
  return b;
}

// Consecutive, non-overlapping windows of sentences with total length in [lo, hi] and at least
// min_sent sentences; the target length is drawn uniformly in [lo, hi] per window (v0 and v1's rule).
std::vector<Sample> make_samples(const std::vector<std::string>& docs, std::size_t lo, std::size_t hi, int min_sent, int max_per_doc,
                                 std::mt19937_64& rng) {
  std::vector<Sample> out;
  std::uniform_real_distribution<double> U(0.0, 1.0);
  for (std::size_t d = 0; d < docs.size(); ++d) {
    const std::vector<std::string> s = split_sentences(docs[d]);
    int got = 0;
    for (std::size_t i = 0; i < s.size() && got < max_per_doc;) {
      const double target = static_cast<double>(lo) + U(rng) * static_cast<double>(hi - lo);
      std::size_t j = i, total = 0;
      while (j < s.size() && static_cast<double>(total) < target) total += s[j++].size() + (total ? 1 : 0);
      if (total >= lo && total <= hi && static_cast<int>(j - i) >= min_sent) {
        std::string t;
        for (std::size_t k = i; k < j; ++k) {
          if (k > i) t.push_back(' ');
          t += s[k];
        }
        out.push_back({std::move(t), static_cast<int>(d)});
        ++got;
        i = j;
      } else {
        ++i;
      }
    }
  }
  return out;
}

std::vector<Sample> pick(std::vector<Sample> v, std::size_t n, std::mt19937_64& rng) {
  std::shuffle(v.begin(), v.end(), rng);
  if (v.size() > n) v.resize(n);
  return v;
}

std::string unescape_gen(const std::string& in) {
  std::string o;
  auto hex = [](char c) { return c >= '0' && c <= '9' ? c - '0' : (c >= 'a' && c <= 'f' ? c - 'a' + 10 : 0); };
  for (std::size_t i = 0; i < in.size(); ++i) {
    if (in[i] == '\\' && i + 1 < in.size() && in[i + 1] == 'n') {
      o.push_back('\n');
      ++i;
    } else if (in[i] == '\\' && i + 3 < in.size() && in[i + 1] == 'x') {
      o.push_back(static_cast<char>((hex(in[i + 2]) << 4) | hex(in[i + 3])));
      i += 3;
    } else {
      o.push_back(in[i]);
    }
  }
  return o;
}

std::vector<std::string> split_ws(const std::string& s) {
  std::vector<std::string> v;
  std::size_t i = 0;
  while (i < s.size()) {
    while (i < s.size() && is_space_a(static_cast<unsigned char>(s[i]))) ++i;
    std::size_t j = i;
    while (j < s.size() && !is_space_a(static_cast<unsigned char>(s[j]))) ++j;
    if (j > i) v.push_back(s.substr(i, j - i));
    i = j;
  }
  return v;
}

std::string join(const std::vector<std::string>& v, const char* sep = " ") {
  std::string o;
  for (std::size_t i = 0; i < v.size(); ++i) {
    if (i) o += sep;
    o += v[i];
  }
  return o;
}

// ===========================================================================
// Controls (unchanged from v0 and v1; each keeps sentence lengths, final punctuation and a capital first letter)
// ===========================================================================

std::string ctl_shuffle_sentences(const Sample& s, const std::vector<std::pair<int, std::string>>& pool, std::mt19937_64& rng) {
  const std::vector<std::string> own = split_sentences(s.text);
  std::string out;
  std::uniform_int_distribution<std::size_t> pickd(0, pool.size() - 1);
  for (std::size_t i = 0; i < own.size(); ++i) {
    const std::string* chosen = nullptr;
    for (int tries = 0; tries < 60; ++tries) {
      const auto& c = pool[pickd(rng)];
      if (c.first == s.doc) continue;
      chosen = &c.second;
      const double r = static_cast<double>(c.second.size()) / static_cast<double>(own[i].size());
      if (r >= 0.6 && r <= 1.7) break;
    }
    if (!chosen) chosen = &pool[pickd(rng)].second;
    if (i) out.push_back(' ');
    out += *chosen;
  }
  return out;
}

std::string ctl_shuffle_words(const std::string& text, std::mt19937_64& rng) {
  std::vector<std::string> sents;
  for (const std::string& s : split_sentences(text)) {
    std::vector<std::string> w = split_ws(s);
    if (w.empty()) continue;
    std::string tail;
    while (!w.back().empty() && std::string(".!?\"')").find(w.back().back()) != std::string::npos) {
      tail.insert(tail.begin(), w.back().back());
      w.back().pop_back();
    }
    if (w.back().empty()) w.pop_back();
    if (w.empty()) {
      sents.push_back(tail);
      continue;
    }
    std::shuffle(w.begin(), w.end(), rng);
    for (char& c : w[0]) {
      if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 32);
      if (is_alpha_a(static_cast<unsigned char>(c))) break;
    }
    sents.push_back(join(w) + tail);
  }
  return join(sents);
}

template <class Fn>
std::string replace_cores(const std::string& text, Fn make_core) {
  std::vector<std::string> w = split_ws(text);
  for (std::string& t : w) {
    bool digit = false;
    for (char c : t) digit = digit || is_digit_a(static_cast<unsigned char>(c));
    if (digit) continue;
    std::size_t b = 0;
    while (b < t.size() && !is_alpha_a(static_cast<unsigned char>(t[b]))) ++b;
    if (b >= t.size()) continue;
    std::size_t e = b;
    while (e < t.size() && (is_alpha_a(static_cast<unsigned char>(t[e])) || t[e] == '\'' || t[e] == '-' || static_cast<unsigned char>(t[e]) >= 0x80))
      ++e;
    std::string core = make_core(t.substr(b, e - b));
    if (is_upper_a(static_cast<unsigned char>(t[b])) && !core.empty() && core[0] >= 'a' && core[0] <= 'z') core[0] = static_cast<char>(core[0] - 32);
    t = t.substr(0, b) + core + t.substr(e);
  }
  return join(w);
}

std::string ctl_random_lexicon(const std::string& text, const ScribeModel& m, std::mt19937_64& rng) {
  std::uniform_real_distribution<double> U(0.0, 1.0);
  return replace_cores(text, [&](const std::string&) {
    for (int k = 0; k < 20; ++k) {
      const std::string& w = m.draw_word(U(rng));
      if (!w.empty() && w[0] != '\'') return w;
    }
    return std::string("the");
  });
}

std::string ctl_random_letters(const std::string& text, std::mt19937_64& rng) {
  return replace_cores(text, [&](const std::string& core) {
    std::string r(core.size(), 'a');
    for (char& c : r) c = static_cast<char>('a' + static_cast<int>(rng() % 26));
    return r;
  });
}

std::string ctl_repeat_phrase(const std::string& text) {
  std::vector<std::string> w = split_ws(text);
  if (w.size() > 6) w.resize(6);
  while (!w.empty()) {
    std::string& last = w.back();
    while (!last.empty() && !is_alpha_a(static_cast<unsigned char>(last.back())) && !is_digit_a(static_cast<unsigned char>(last.back())) &&
           static_cast<unsigned char>(last.back()) < 0x80)
      last.pop_back();
    if (last.empty()) w.pop_back();
    else break;
  }
  std::string phrase = join(w) + ".";
  std::string out;
  while (out.size() < text.size()) {
    if (!out.empty()) out.push_back(' ');
    out += phrase;
  }
  return out;
}

// ===========================================================================
// The pack (everything trained on the pack text) and the human reference
// ===========================================================================

struct Ctx {
  ScribeModel model;
  WordVectors wv;
  SentenceEmbedder emb;
  SurfaceRef surf;
  ScribeScorer scorer;   // v1
  ScribeV2Scorer v2;     // v2
  SurpriseModel sm;      // v3: SURPRISE's model (on top of `model`)
  PackIndex px;          // v3: MATCH's suffix array over the pack
  V3Scorer v3s;          // v3: SURPRISE and MATCH against the reference
  V3Scorer v31s;         // v3.1 (profile v31 only): SURPRISE and MATCH with the v3.1 statistics
  WordDict dict;
  bool use_vectors = false;
  std::string profile = "v2";
  std::size_t n_pack_docs = 0, pack_bytes = 0, n_ref_std = 0, n_ref_short = 0;
  std::vector<Features> ref_feats;  // reference samples, both buckets
  std::vector<std::string> ref_texts;  // their texts (same order)
  bool v3() const { return profile == "v3" || profile == "v31"; }  // the v3 judges are built (v31 scores them too)
  bool v31() const { return profile == "v31"; }
  const SentenceEmbedder* embedder() const { return use_vectors ? &emb : nullptr; }
};

// --v2 "k=v,..." (V2Params::parse) must be set before the reference is built: the thresholds depend on it.
// Profile v2p (prompted) is v2 with wR = 8; its headline is the same `scribe_v2` field.
void set_v2_params(Ctx& c, const std::string& spec) {
  if (c.profile == "v2p") c.v2.params.wR = 8;
  if (spec.empty()) return;
  if (!c.v2.params.parse(spec)) {
    std::fprintf(stderr, "bad --v2 parameters: %s\n", spec.c_str());
    std::exit(2);
  }
}

// --v3 "w.tau=..,m.wC=..,..." (V3Params::parse), before the reference is built. In profile v31, --v3 sets the v3.1
// judges (on top of their v31 defaults) and the v3 judges stay as frozen.
void set_v3_params(Ctx& c, const std::string& spec) {
  if (c.profile != "v1" && c.profile != "v2" && c.profile != "v2p" && c.profile != "v3" && c.profile != "v31") {
    std::fprintf(stderr, "unknown --profile %s (v1, v2, v2p, v3 or v31)\n", c.profile.c_str());
    std::exit(2);
  }
  if (c.v31()) c.v31s.params.set_v31();
  if (spec.empty()) return;
  if (!c.v3()) {
    std::fprintf(stderr, "--v3 needs --profile v3 or v31\n");
    std::exit(2);
  }
  if (!(c.v31() ? c.v31s.params : c.v3s.params).parse(spec)) {
    std::fprintf(stderr, "bad --v3 parameters: %s\n", spec.c_str());
    std::exit(2);
  }
}

void build_pack(Ctx& c, const std::vector<std::string>& pack_docs, const std::string& vec_prefix) {
  if (pack_docs.empty()) {  // an empty pack would make every statistic missing and every score 1
    std::fprintf(stderr, "the pack has no documents (wrong path, or lowercased JSONL that needs the raw: prefix?)\n");
    std::exit(1);
  }
  for (const auto& d : pack_docs) c.pack_bytes += d.size();
  c.n_pack_docs = pack_docs.size();
  double t0 = now_s();
  c.model.train(pack_docs);
  g_t_pack_model = now_s() - t0;
  t0 = now_s();
  c.v2.train_pack(pack_docs);
  g_t_pack_v2 = now_s() - t0;
  for (const auto& d : pack_docs) surface_add_vocab(c.surf, d);
  if (c.v3()) {
    t0 = now_s();
    c.sm.train(c.model, pack_docs);
    const double t1 = now_s();
    c.px.build(pack_docs, 4);
    std::fprintf(stderr, "[%.0fs] v3: spelling models from %zu once-seen and %zu number types (%.1f s); pack suffix array over %zu bytes, %.0f MB (%.1f s)\n",
                 now_s() - g_t0, c.sm.n_once_types(), c.sm.n_number_types(), t1 - t0, c.px.size(), static_cast<double>(c.px.bytes()) / 1048576.0,
                 now_s() - t1);
  }
  std::fprintf(stderr, "[%.0fs] pack: %zu docs, %zu bytes; vocab %zu, %zu trigrams\n", now_s() - g_t0, c.n_pack_docs, c.pack_bytes,
               c.model.vocab_size(), c.model.n_trigrams());
  if (vec_prefix.empty()) {
    std::fprintf(stderr, "no --vectors: C falls back to TF-IDF cosines (C0 absent)\n");
    return;
  }
  if (!c.wv.load(vec_prefix)) {
    std::fprintf(stderr, "cannot load word vectors %s.{vectors.f32,vocab.tsv} (300 dimensions)\n", vec_prefix.c_str());
    std::exit(1);
  }
  const double tv = now_s();
  c.emb = SentenceEmbedder(&c.wv, 1e-3);
  std::vector<std::vector<float>> X;
  std::mt19937_64 prng(5);
  std::vector<std::string> toks;
  for (std::size_t d = 0; d < pack_docs.size() && X.size() < 60000; ++d) {
    for (const std::string& s : split_sentences(pack_docs[d])) {
      if (prng() % 8 != 0) continue;
      toks.clear();
      tokenize_words(s, toks);
      std::vector<float> v;
      if (toks.size() >= 3 && c.emb.raw(toks, v)) X.push_back(std::move(v));
    }
  }
  c.emb.fit_pc(X);
  c.use_vectors = true;
  g_t_pack_vec = now_s() - tv;
  std::fprintf(stderr, "[%.0fs] word vectors: %zu words x %zu; principal component from %zu pack sentences\n", now_s() - g_t0, c.wv.size(), c.wv.dim(),
               X.size());
}

Features featurize(Ctx& c, const std::string& text, const std::string& prompt = "") {
  const double t0 = now_s();
  Features f = extract_features(c.model, c.dict, text, c.embedder());
  const double t1 = now_s();
  c.v2.extend(f, text, prompt, c.embedder());
  g_t_extract += t1 - t0;
  g_t_extend += now_s() - t1;
  ++g_n_feat;
  return f;
}

struct PromptPair {
  std::string prompt, cont;
  int doc = 0;
};

// Prompt / true continuation pairs, at most one per document, in a random document order: a run of whole sentences of
// 100-300 bytes from a random sentence, then the next whole sentences, 400-600 bytes (target drawn uniformly), at least
// 3 sentences (cmd_prompts' rule).
std::vector<PromptPair> make_prompt_pairs(const std::vector<std::string>& docs, std::size_t n, std::mt19937_64& rng) {
  std::vector<std::size_t> order(docs.size());
  std::iota(order.begin(), order.end(), std::size_t{0});
  std::shuffle(order.begin(), order.end(), rng);
  std::uniform_real_distribution<double> U(0.0, 1.0);
  std::vector<PromptPair> out;
  for (std::size_t d : order) {
    if (out.size() >= n) break;
    const std::vector<std::string> s = split_sentences(docs[d]);
    if (s.size() < 5) continue;
    for (int tries = 0; tries < 6; ++tries) {
      const std::size_t i0 = static_cast<std::size_t>(U(rng) * static_cast<double>(s.size() - 4));
      std::size_t j = i0, pb = 0;
      while (j < s.size() && pb < 100) pb += s[j++].size() + (pb ? 1 : 0);
      if (pb < 100 || pb > 300) continue;
      const double target = 400.0 + U(rng) * 200.0;
      std::size_t k = j, cb = 0;
      while (k < s.size() && static_cast<double>(cb) < target) cb += s[k++].size() + (cb ? 1 : 0);
      if (cb < 400 || cb > 600 || k - j < 3) continue;
      PromptPair p;
      for (std::size_t q = i0; q < j; ++q) p.prompt += (q > i0 ? " " : "") + s[q];
      for (std::size_t q = j; q < k; ++q) p.cont += (q > j ? " " : "") + s[q];
      p.doc = static_cast<int>(d);
      out.push_back(std::move(p));
      break;
    }
  }
  return out;
}

// v3's reference: the same human samples as v2's (SURPRISE and MATCH), and, for MATCH's echo, the continuations of up
// to 1,000 prompts drawn from the reference documents with a generator of its own (v2's draws are not touched).
void build_reference_v3(Ctx& c, const std::vector<std::string>& ref_docs) {
  if (!c.v3()) return;
  const double t0 = now_s();
  for (const V3Features& f : extract_v3_all(c.sm, c.px, c.ref_texts, {}, 4, false, c.v31())) {
    c.v3s.add_reference(f);
    if (c.v31()) c.v31s.add_reference(f);
  }
  std::mt19937_64 prng(20261104);
  const std::vector<PromptPair> pp = make_prompt_pairs(ref_docs, 1000, prng);
  std::vector<std::string> texts, prompts;
  for (const PromptPair& p : pp) {
    texts.push_back(p.cont);
    prompts.push_back(p.prompt);
  }
  for (const V3Features& f : extract_v3_all(c.sm, c.px, texts, prompts, 4, false, c.v31())) {
    c.v3s.add_reference_echo(f);
    if (c.v31()) c.v31s.add_reference_echo(f);
  }
  c.v3s.finish();
  if (c.v31()) c.v31s.finish();
  std::fprintf(stderr,
               "[%.0fs] v3 reference: %zu standard + %zu short samples, %zu prompted continuations for the echo; word thresholds %.2f / %.2f bits "
               "(%.1f s)\n",
               now_s() - g_t0, c.v3s.n_reference(1), c.v3s.n_reference(0), pp.size(), c.v3s.threshold_lo(), c.v3s.threshold_hi(), now_s() - t0);
}

// Reference samples from ref_docs with rng (v1's draw order: standard first, then short). ref_prompts (optional):
// JSONL of human prompt / continuation pairs (`scribe prompts` on the reference range) for the relevance statistics.
// ref_whole: every reference document is one sample as it is (for sets whose units are short whole texts, such as
// five-sentence ROC stories), instead of sentence windows.
void build_reference(Ctx& c, const std::vector<std::string>& ref_docs, std::mt19937_64& rng, const std::string& ref_prompts = "",
                     bool ref_whole = false, std::size_t ref_n = 0) {
  std::vector<Sample> ref_std, ref_short;
  if (ref_whole) {
    for (std::size_t d = 0; d < ref_docs.size(); ++d)
      if (ref_docs[d].size() >= 60) (length_bucket(ref_docs[d].size()) ? ref_std : ref_short).push_back({ref_docs[d], static_cast<int>(d)});
  } else {
    ref_std = make_samples(ref_docs, 400, 600, 3, 4, rng);
    ref_short = make_samples(ref_docs, 60, 260, 1, 3, rng);
  }
  if (ref_n > 0) {  // --ref-n: a random subset of N reference samples per length bucket (profiling the reference size)
    std::mt19937_64 sr(77);
    for (auto* v : {&ref_std, &ref_short}) {
      std::shuffle(v->begin(), v->end(), sr);
      if (v->size() > ref_n) v->resize(ref_n);
    }
  }
  c.n_ref_std = ref_std.size();
  c.n_ref_short = ref_short.size();
  if (c.n_ref_std < 20 && c.n_ref_short < 20) {  // below this no bucket has a distribution to score against
    std::fprintf(stderr, "the reference has %zu standard and %zu short samples; at least 20 in one bucket are needed\n", c.n_ref_std, c.n_ref_short);
    std::exit(1);
  }
  if (c.profile == "v2p" && ref_prompts.empty()) {  // without it relevance would silently count as 0
    std::fprintf(stderr, "profile v2p needs --ref-prompts (human prompt-continuation pairs of the genre)\n");
    std::exit(2);
  }
  c.ref_feats.reserve(ref_std.size() + ref_short.size());
  for (const auto* v : {&ref_std, &ref_short})
    for (const Sample& s : *v) {
      c.ref_feats.push_back(featurize(c, s.text));
      c.ref_texts.push_back(s.text);
    }
  for (const Features& f : c.ref_feats) {
    c.scorer.add_reference(f);
    c.v2.add_reference(f);
  }
  if (!ref_prompts.empty()) {
    for (const JsonObj& j : read_jsonl(ref_prompts)) c.v2.add_reference_prompted(featurize(c, j.get("text"), j.get("prompt")));
    std::fprintf(stderr, "[%.0fs] prompted reference: %zu standard + %zu short continuations\n", now_s() - g_t0, c.v2.n_reference_prompted(1),
                 c.v2.n_reference_prompted(0));
  }
  c.scorer.finish();
  c.v2.finish();
  double sd[2] = {0, 0}, sl[2] = {0, 0}, sn[2] = {0, 0};
  for (std::size_t i = 0; i < c.ref_feats.size(); ++i) {
    const std::string& t = i < ref_std.size() ? ref_std[i].text : ref_short[i - ref_std.size()].text;
    const int b = length_bucket(t.size());
    sd[b] += scribe_detail::distinct4_bytes(t);
    sl[b] += c.ref_feats[i].loop8;
    sn[b] += 1;
  }
  for (int b = 0; b < 2; ++b) {
    c.surf.ref_d4[b] = sn[b] ? sd[b] / sn[b] : 0.9;
    c.surf.ref_loop[b] = sn[b] ? sl[b] / sn[b] : 0;
  }
  std::fprintf(stderr, "[%.0fs] reference: %zu standard + %zu short samples\n", now_s() - g_t0, c.n_ref_std, c.n_ref_short);
  build_reference_v3(c, ref_docs);
}

// The per-sample result in every profile (v3 only with --profile v3 or v31; v3.1 only with v31).
struct Result {
  Scored v1;
  ScoredV2 v2;
  double surface = 0;
  bool has_v3 = false, has_v31 = false;
  ScoredV3 v3, v31;  // v31: SURPRISE and MATCH with the v3.1 statistics
  V3Combined comb;
  double score31 = 0;  // SCRIBE v3.1
  double headline(const std::string& profile) const {
    if (profile == "v3") return comb.v3;
    if (profile == "v31") return score31;
    return profile == "v1" ? v1.scribe : v2.scribe;  // v2 or v2p
  }
};

Result score_one(const Ctx& c, const Features& f, const std::string& text, const V3Features* f3 = nullptr) {
  Result r;
  r.v1 = c.scorer.score(f);
  r.v2 = c.v2.score(f);
  r.surface = surface_S(c.surf, text);
  if (c.v3() && f3) {
    r.has_v3 = true;
    r.v3 = c.v3s.score(*f3);
    r.comb = combine_v3(r.v2.scribe, r.v3.surprise, r.v3.match, c.v3s.params.disagree);
    if (c.v31()) {
      r.has_v31 = true;
      r.v31 = c.v31s.score(*f3);
      r.score31 = combine_v31(r.v2.scribe, r.v31.surprise, r.v31.match, c.v31s.params.cp);
    }
  }
  return r;
}

// The JSON members of one scored sample: headline, every profile, raw statistics.
std::string result_json(const Features& f, const Result& r, const std::string& profile, const V3Features* f3 = nullptr) {
  std::string o = "\"scribe\":" + num(r.headline(profile)) + ",\"scribe_v1\":" + num(r.v1.scribe) + ",\"scribe_v2\":" + num(r.v2.scribe) +
                  ",\"surface_s\":" + num(r.surface);
  if (r.has_v3)
    o += ",\"scribe_v3\":" + num(r.comb.v3) + ",\"surprise\":" + num(r.v3.surprise) + ",\"match\":" + num(r.v3.match) + ",\"min3\":" + num(r.comb.min3) +
         ",\"disagree\":" + (r.comb.disagree ? "1" : "0");
  if (r.has_v31)
    o += ",\"scribe_v31\":" + num(r.score31) + ",\"surprise31\":" + num(r.v31.surprise) + ",\"match31\":" + num(r.v31.match) + ",\"v31\":" +
         v3_json(r.v31, combine_v3(r.v2.scribe, r.v31.surprise, r.v31.match));
  o += ",\"v1\":{\"S\":" + num(r.v1.S) + ",\"C\":" + num(f.has_c ? r.v1.C : NAN) + ",\"I\":" + num(r.v1.I) + ",\"s_gate\":" + (r.v1.s_gate ? "1" : "0") +
       ",\"i_gate\":" + (r.v1.i_gate ? "1" : "0") + "}";
  o += ",\"v2\":" + v2_json(r.v2);
  if (r.has_v3) o += ",\"v3\":" + v3_json(r.v3, r.comb);
  o += ",\"raw\":" + features_json(f);
  if (r.has_v3 && f3) o += ",\"raw3\":" + v3_raw_json(*f3);
  return o;
}

// ===========================================================================
// docs / prompts / samples / prepare
// ===========================================================================

struct Args {
  std::map<std::string, std::string> kv;
  std::vector<std::string> multi_model;
  std::vector<std::string> pos;
  std::map<std::string, bool> flag;
  std::string get(const std::string& k, const std::string& d = "") const {
    const auto it = kv.find(k);
    return it == kv.end() ? d : it->second;
  }
  bool has(const std::string& k) const { return flag.count(k) > 0; }
};

Args parse_args(int argc, char** argv, int from) {
  static const std::vector<std::string> flags = {"--short", "--chain-rng", "--quiet", "--window", "--ref-whole", "--timing", "--heldout", "--dedup"};
  Args a;
  for (int i = from; i < argc; ++i) {
    const std::string s = argv[i];
    if (s.rfind("--", 0) == 0) {
      if (std::find(flags.begin(), flags.end(), s) != flags.end()) {
        a.flag[s] = true;
      } else if (i + 1 < argc) {
        if (s == "--model") a.multi_model.push_back(argv[++i]);
        else a.kv[s] = argv[++i];
      } else {
        std::fprintf(stderr, "missing value for %s\n", s.c_str());
        std::exit(2);
      }
    } else {
      a.pos.push_back(s);
    }
  }
  return a;
}

std::ofstream open_out(const std::string& path) {
  if (path.empty()) {
    std::fprintf(stderr, "need --out\n");
    std::exit(2);
  }
  std::ofstream o(path);
  if (!o) {
    std::fprintf(stderr, "cannot write %s\n", path.c_str());
    std::exit(1);
  }
  return o;
}

// dedup --pack SRC --ref SRC --test SRC: how many test documents the near-duplicate filter (--dedup) would drop. It
// scores nothing, so it can be run on a fresh region before that region is read.
int cmd_dedup(const Args& a) {
  const std::vector<std::string> pack_docs = load_docs(a.get("--pack"));
  const std::vector<std::string> ref_docs = load_docs(a.get("--ref"));
  std::vector<std::string> test_docs = load_docs(a.get("--test"));
  std::printf("%s\n", apply_dedup(test_docs, pack_docs, ref_docs).c_str());
  return 0;
}

int cmd_docs(const Args& a) {
  if (a.pos.empty()) return 2;
  const std::vector<std::string> docs = load_docs(a.pos[0]);
  std::ofstream o = open_out(a.get("--out"));
  const std::string set = a.get("--set", "docs");
  std::size_t bytes = 0;
  for (std::size_t i = 0; i < docs.size(); ++i) {
    char id[64];
    std::snprintf(id, sizeof id, "%s/%06zu", set.c_str(), i);
    o << text_line(id, set, "human", docs[i]) << "\n";
    bytes += docs[i].size();
  }
  std::fprintf(stderr, "%zu documents, %zu bytes\n", docs.size(), bytes);
  return 0;
}

// One prompt per document: a run of whole sentences of 100-300 bytes from a random sentence of the document, then the
// true continuation: the next whole sentences, 400-600 bytes (target drawn uniformly), at least 3 sentences.
int cmd_prompts(const Args& a) {
  if (a.pos.empty()) return 2;
  const std::vector<std::string> docs = load_docs(a.pos[0]);
  const std::size_t n = std::strtoull(a.get("--n", "250").c_str(), nullptr, 10);
  std::mt19937_64 rng(std::strtoull(a.get("--seed", "1").c_str(), nullptr, 10));
  const std::string set = a.get("--set", "prompts");
  std::vector<std::size_t> order(docs.size());
  std::iota(order.begin(), order.end(), std::size_t{0});
  std::shuffle(order.begin(), order.end(), rng);
  std::ofstream o = open_out(a.get("--out"));
  std::uniform_real_distribution<double> U(0.0, 1.0);
  const int per_doc = std::atoi(a.get("--per-doc", "1").c_str());
  std::size_t made = 0;
  for (std::size_t d : order) {
    if (made >= n) break;
    const std::vector<std::string> s = split_sentences(docs[d]);
    if (s.size() < 5) continue;
    if (per_doc > 1) {
      // Consecutive, non-overlapping prompt + continuation windows from the start of the document.
      int got = 0;
      for (std::size_t i0 = 0; i0 + 4 < s.size() && got < per_doc && made < n;) {
        std::size_t j = i0, pb = 0;
        while (j < s.size() && pb < 100) pb += s[j++].size() + (pb ? 1 : 0);
        const double target = 400.0 + U(rng) * 200.0;
        std::size_t k = j, cb = 0;
        while (k < s.size() && static_cast<double>(cb) < target) cb += s[k++].size() + (cb ? 1 : 0);
        if (pb < 100 || pb > 300 || cb < 400 || cb > 600 || k - j < 3) {
          ++i0;
          continue;
        }
        std::vector<std::string> ps(s.begin() + static_cast<std::ptrdiff_t>(i0), s.begin() + static_cast<std::ptrdiff_t>(j));
        std::vector<std::string> cs(s.begin() + static_cast<std::ptrdiff_t>(j), s.begin() + static_cast<std::ptrdiff_t>(k));
        const std::string ref = join(cs);
        char id[64];
        std::snprintf(id, sizeof id, "%s/%04zu", set.c_str(), made);
        o << text_line(id, set, "human", ref, join(ps), ref, "\"meta\":{\"doc\":" + std::to_string(d) + "}") << "\n";
        ++made;
        ++got;
        i0 = k;
      }
      continue;
    }
    bool done = false;
    for (int tries = 0; tries < 6 && !done; ++tries) {
      const std::size_t i0 = static_cast<std::size_t>(U(rng) * static_cast<double>(s.size() - 4));
      std::size_t j = i0, pb = 0;
      while (j < s.size() && pb < 100) pb += s[j++].size() + (pb ? 1 : 0);
      if (pb < 100 || pb > 300) continue;
      const double target = 400.0 + U(rng) * 200.0;
      std::size_t k = j, cb = 0;
      while (k < s.size() && static_cast<double>(cb) < target) cb += s[k++].size() + (cb ? 1 : 0);
      if (cb < 400 || cb > 600 || k - j < 3) continue;
      std::vector<std::string> ps(s.begin() + static_cast<std::ptrdiff_t>(i0), s.begin() + static_cast<std::ptrdiff_t>(j));
      std::vector<std::string> cs(s.begin() + static_cast<std::ptrdiff_t>(j), s.begin() + static_cast<std::ptrdiff_t>(k));
      const std::string ref = join(cs);
      char id[64];
      std::snprintf(id, sizeof id, "%s/%04zu", set.c_str(), made);
      o << text_line(id, set, "human", ref, join(ps), ref, "\"meta\":{\"doc\":" + std::to_string(d) + "}") << "\n";
      ++made;
      done = true;
    }
  }
  std::fprintf(stderr, "%zu prompts from %zu documents\n", made, docs.size());
  return made ? 0 : 1;
}

int cmd_samples(const Args& a) {
  if (a.pos.empty()) return 2;
  const std::vector<std::string> docs = load_docs(a.pos[0]);
  const std::size_t n = std::strtoull(a.get("--n", "500").c_str(), nullptr, 10);
  std::mt19937_64 rng(std::strtoull(a.get("--seed", "1").c_str(), nullptr, 10));
  const bool shrt = a.has("--short");
  std::vector<Sample> all = shrt ? make_samples(docs, 60, 260, 1, 3, rng) : make_samples(docs, 400, 600, 3, 4, rng);
  const std::size_t cand = all.size();
  const std::vector<Sample> got = pick(std::move(all), n, rng);
  std::ofstream o = open_out(a.get("--out"));
  const std::string set = a.get("--set", "samples"), system = a.get("--system", "human");
  for (std::size_t i = 0; i < got.size(); ++i) {
    char id[96];
    std::snprintf(id, sizeof id, "%s/%s/%04zu", set.c_str(), system.c_str(), i);
    o << text_line(id, set, system, got[i].text, "", "", "\"meta\":{\"doc\":" + std::to_string(got[i].doc) + "}") << "\n";
  }
  std::fprintf(stderr, "%zu samples (of %zu candidates) from %zu documents\n", got.size(), cand, docs.size());
  return 0;
}

int cmd_prepare(const Args& a) {
  const std::string mode = a.get("--mode", "continuation");
  const std::size_t min_bytes = std::strtoull(a.get("--min-bytes", "100").c_str(), nullptr, 10);
  std::ofstream o = open_out(a.get("--out"));
  std::size_t n = 0, kept = 0, raw_b = 0, kept_b = 0;
  for (const JsonObj& j : read_jsonl(a.get("--in"))) {
    ++n;
    const std::string raw = j.get("text");
    raw_b += raw.size();
    std::string t;
    if (mode == "wikiraw") t = clean_generated_text(raw);
    else if (mode == "plain") t = scribe_detail::collapse_ws(collapse_newlines(raw));
    else t = prepare_continuation(raw);
    if (t.size() < min_bytes) continue;
    ++kept;
    kept_b += t.size();
    o << text_line(j.get("id"), j.get("set"), j.get("system"), t, j.get("prompt"), j.get("ref")) << "\n";
  }
  std::fprintf(stderr, "prepare (%s): %zu texts, %zu kept (>= %zu B); mean bytes raw %.0f, kept %.0f\n", mode.c_str(), n, kept, min_bytes,
               n ? double(raw_b) / double(n) : 0.0, kept ? double(kept_b) / double(kept) : 0.0);
  return 0;
}

// ===========================================================================
// ladder
// ===========================================================================

struct Rung {
  std::string key, name;
  std::vector<std::string> texts, ids, kinds;
  std::vector<std::string> prompts;  // v3: the prompt of each text ("" when none)
  std::vector<Features> feats;
  std::vector<V3Features> f3;        // v3 only
  std::vector<Result> res;
  std::vector<double> scribe, surf;
  std::pair<double, double> ci_scribe{0, 0}, ci_surf{0, 0};
};

std::string fmt(double v, int prec = 3) {
  char b[64];
  std::snprintf(b, sizeof b, "%.*f", prec, v);
  return b;
}
std::string fmt_ci(double m, std::pair<double, double> ci, int prec = 3) {
  return fmt(m, prec) + " [" + fmt(ci.first, prec) + ", " + fmt(ci.second, prec) + "]";
}

struct GenSet {
  std::vector<std::string> texts, kinds, prompts;  // prompts: the PROMPT line before each GEN line ("" if none)
  std::size_t lines = 0, dropped = 0;
};

// GEN lines of a cyphalm_trie sample file -> clean_generated_text; under 100 bytes dropped (v1's rule).
GenSet load_gen_trie(const std::string& path) {
  GenSet g;
  std::ifstream in(path);
  std::string line, prompt;
  while (std::getline(in, line)) {
    if (line.compare(0, 7, "PROMPT\t") == 0) {
      const std::size_t t2 = line.find('\t', 7);
      prompt = t2 == std::string::npos ? std::string() : unescape_gen(line.substr(t2 + 1));
      continue;
    }
    if (line.compare(0, 4, "GEN\t") != 0) continue;
    const std::size_t t2 = line.find('\t', 4);
    if (t2 == std::string::npos) continue;
    ++g.lines;
    const std::string text = clean_generated_text(unescape_gen(line.substr(t2 + 1)));
    if (text.size() < 100) {
      ++g.dropped;
      continue;
    }
    g.texts.push_back(text);
    g.kinds.push_back(line.substr(4, t2 - 4));
    g.prompts.push_back(prompt);
  }
  return g;
}

// The v3 reference as scored by itself (z of every statistic), and the echo reference's z: for design work. In
// profile v31 also reference31.jsonl: the same for the v3.1 judges, with the z of every prompt statistic.
void export_v3_reference(const Ctx& c, const std::string& dir) {
  std::ofstream o(dir + "/reference3.jsonl");
  for (int b = 0; b < 2; ++b) {
    for (const V3Features& f : c.v3s.reference(b)) {
      const ScoredV3 s = c.v3s.score(f);
      o << "{\"bucket\":" << b << ",\"v3\":" << v3_json(s, combine_v3(1, s.surprise, s.match)) << ",\"raw3\":" << v3_raw_json(f) << "}\n";
    }
    const std::vector<double> z8 = c.v3s.echo_reference_z(b, 0), z32 = c.v3s.echo_reference_z(b, 1);
    for (std::size_t i = 0; i < z8.size(); ++i)
      o << "{\"bucket\":" << b << ",\"echo_z\":" << num(z8[i], 6) << ",\"echo32_z\":" << num(z32[i], 6) << "}\n";
  }
  if (!c.v31()) return;
  std::ofstream o31(dir + "/reference31.jsonl");
  for (int b = 0; b < 2; ++b) {
    for (const V3Features& f : c.v31s.reference(b)) {
      const ScoredV3 s = c.v31s.score(f);
      o31 << "{\"bucket\":" << b << ",\"v3\":" << v3_json(s, combine_v3(1, s.surprise, s.match)) << ",\"raw3\":" << v3_raw_json(f) << "}\n";
    }
    std::vector<std::vector<double>> pz;
    const std::vector<int> pk = {M_ECHO, M_ECHO32, W_PGAIN, W_LEAD, M_PCOH, M_ECHO64};
    for (int k : pk) pz.push_back(c.v31s.echo_reference_z(b, k == M_ECHO ? 0 : k == M_ECHO32 ? 1 : k));
    for (std::size_t i = 0; i < pz[0].size(); ++i) {
      o31 << "{\"bucket\":" << b << ",\"prompted_z\":{";
      for (std::size_t j = 0; j < pk.size(); ++j)
        o31 << (j ? "," : "") << "\"" << v3_spec(pk[j]).name << "\":" << (i < pz[j].size() ? num(pz[j][i], 6) : std::string("null"));
      o31 << "}}\n";
    }
  }
}

// The v3 section of the ladder report: each judge on its own (v2, SURPRISE, MATCH), their mean (v3) and their minimum,
// per rung and per adjacent pair of every chain. PASS = accuracy >= 0.95 and disjoint 95% intervals, as for v2.
void print_v3_ladder(const Ctx& c, const std::vector<Rung>& rungs, const std::vector<std::pair<std::string, std::vector<std::size_t>>>& chains,
                     std::uint64_t seed) {
  const char* mname[8] = {"v2", "SURPRISE", "MATCH", "v3", "min of 3", "SURPRISE 3.1", "MATCH 3.1", "v3.1"};
  const int NM = c.v31() ? 8 : 5;
  const std::size_t R = rungs.size();
  std::vector<std::array<std::vector<double>, 8>> sc(R);
  std::vector<std::array<std::pair<double, double>, 8>> ci(R);
  for (std::size_t i = 0; i < R; ++i) {
    for (const Result& x : rungs[i].res) {
      sc[i][0].push_back(x.v2.scribe);
      sc[i][1].push_back(x.v3.surprise);
      sc[i][2].push_back(x.v3.match);
      sc[i][3].push_back(x.comb.v3);
      sc[i][4].push_back(x.comb.min3);
      if (NM > 5) {
        sc[i][5].push_back(x.v31.surprise);
        sc[i][6].push_back(x.v31.match);
        sc[i][7].push_back(x.score31);
      }
    }
    for (int m = 0; m < NM; ++m) ci[i][static_cast<std::size_t>(m)] = bootstrap_mean_ci(sc[i][static_cast<std::size_t>(m)], 1000, 5000 + seed % 1000 + 10 * i + static_cast<std::size_t>(m));
  }
  std::printf("\n## SCRIBE v3: the three judges and their mean\n\n");
  std::printf("v3 = mean(v2, SURPRISE, MATCH). Reference word thresholds for SURPRISE: %.2f and %.2f bits; MATCH's echo reference: %zu standard + %zu short "
              "prompted continuations.\n\n",
              c.v3s.threshold_lo(), c.v3s.threshold_hi(), c.v3s.n_reference_echo(1), c.v3s.n_reference_echo(0));
  if (NM > 5)
    std::printf("v3.1 (docs/reports/SCRIBE_V31.md) = the power mean (exponent %g; 0 = geometric) of v2, SURPRISE 3.1 and MATCH 3.1, the new judges with "
                "the v3.1 statistics; fit threshold %.2f bits.\n\n",
                c.v31s.params.cp, c.v31s.threshold_fit());
  std::printf("| rung | n | v2 | SURPRISE | MATCH | v3 | min of 3 |%s disagree |\n|---|---|---|---|---|---|---|%s---|\n",
              NM > 5 ? " SURPRISE 3.1 | MATCH 3.1 | v3.1 |" : "", NM > 5 ? "---|---|---|" : "");
  for (std::size_t i = 0; i < R; ++i) {
    if (rungs[i].res.empty()) continue;
    double dis = 0;
    for (const Result& x : rungs[i].res) dis += x.comb.disagree;
    std::printf("| %s | %zu", rungs[i].name.c_str(), rungs[i].res.size());
    for (int m = 0; m < NM; ++m)
      std::printf(" | %s", fmt_ci(mean_of(sc[i][static_cast<std::size_t>(m)]), ci[i][static_cast<std::size_t>(m)]).c_str());
    std::printf(" | %.0f%% |\n", 100.0 * dis / static_cast<double>(rungs[i].res.size()));
  }
  for (int which = 0; which < (NM > 5 ? 2 : 1); ++which) {
    const int ng = which ? 6 : 4;  // v3.1 adds F (foreign words) and B (bland)
    if (!which) {
      std::printf("\nDeviance terms (mean over samples; L lexical, S order, C cohesion, P too predictable):\n\n");
      std::printf("| rung | SURPRISE D | D_L | D_S | D_C | D_P | MATCH D | D_L | D_S | D_C | D_P |\n|---|---|---|---|---|---|---|---|---|---|---|\n");
    } else {
      std::printf("\nDeviance terms of the v3.1 judges (mean over samples; L lexical, S order, C cohesion, P too predictable, F foreign words, B bland):\n\n");
      std::printf("| rung | SURPRISE D | D_L | D_S | D_C | D_P | D_F | D_B | MATCH D | D_L | D_S | D_C | D_P | D_F | D_B |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n");
    }
    for (std::size_t i = 0; i < R; ++i) {
      if (rungs[i].res.empty()) continue;
      double a[2][7] = {};
      for (const Result& x : rungs[i].res) {
        const ScoredV3& s = which ? x.v31 : x.v3;
        for (int m = 0; m < 2; ++m) {
          a[m][0] += s.D[m];
          for (int g = 0; g < ng; ++g) a[m][g + 1] += s.Dg[m][g];
        }
      }
      const double n = static_cast<double>(rungs[i].res.size());
      std::printf("| %s", rungs[i].name.c_str());
      for (int m = 0; m < 2; ++m)
        for (int g = 0; g <= ng; ++g) std::printf(" | %.2f", a[m][g] / n);
      std::printf(" |\n");
    }
  }
  for (const auto& ch : chains) {
    std::printf("\n### v3 parts: %s\n\n| upper > lower | v2 | | SURPRISE | | MATCH | | v3 | | min of 3 | |%s\n|---|---|---|---|---|---|---|---|---|---|---|%s\n",
                ch.first.c_str(), NM > 5 ? " SURPRISE 3.1 | | MATCH 3.1 | | v3.1 | |" : "", NM > 5 ? "---|---|---|---|---|---|" : "");
    int np = 0, pass[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    for (std::size_t k = 0; k + 1 < ch.second.size(); ++k) {
      const std::size_t x = ch.second[k], y = ch.second[k + 1];
      std::printf("| %s > %s", rungs[x].name.c_str(), rungs[y].name.c_str());
      for (int m = 0; m < NM; ++m) {
        const std::size_t mm = static_cast<std::size_t>(m);
        const double acc = pairwise_accuracy(sc[x][mm], sc[y][mm]);
        const bool ok = acc >= 0.95 && ci[x][mm].first > ci[y][mm].second;
        pass[m] += ok;
        std::printf(" | %.3f | %s", acc, ok ? "PASS" : (acc >= 0.95 ? "FAIL (overlap)" : "FAIL"));
      }
      std::printf(" |\n");
      ++np;
    }
    std::printf("\nPairs passed (%s):", ch.first.c_str());
    for (int m = 0; m < NM; ++m) std::printf(" %s %d of %d%s", mname[m], pass[m], np, m < NM - 1 ? ";" : "");
    std::printf("\n");
  }
}

int cmd_ladder(const Args& a) {
  Ctx c;
  c.profile = a.get("--profile", "v2");
  const std::string label = a.get("--label", "ladder");
  const std::uint64_t ref_seed = std::strtoull(a.get("--ref-seed", "20261027").c_str(), nullptr, 10);
  const std::uint64_t seed = std::strtoull(a.get("--seed", "31415926").c_str(), nullptr, 10);
  const std::vector<std::string> pack_docs = load_docs(a.get("--pack"));
  const std::vector<std::string> ref_docs = load_docs(a.get("--ref"));
  std::vector<std::string> test_docs = load_docs(a.get("--test"));
  if (a.has("--dedup")) g_dedup_note = apply_dedup(test_docs, pack_docs, ref_docs);
  std::fprintf(stderr, "[%.0fs] docs: pack %zu, ref %zu, test %zu\n", now_s() - g_t0, pack_docs.size(), ref_docs.size(), test_docs.size());
  set_v2_params(c, a.get("--v2"));
  set_v3_params(c, a.get("--v3"));
  build_pack(c, pack_docs, a.get("--vectors"));
  std::mt19937_64 rng(ref_seed);
  build_reference(c, ref_docs, rng, a.get("--ref-prompts"), a.has("--ref-whole"), std::strtoull(a.get("--ref-n", "0").c_str(), nullptr, 10));

  // ---- samples: --chain-rng continues the reference draws (v1's development ladder), else a fresh generator.
  std::mt19937_64 trng(seed);
  std::mt19937_64& srng = a.has("--chain-rng") ? rng : trng;
  std::vector<Sample> test_std_all = make_samples(test_docs, 400, 600, 3, 4, srng);
  const std::size_t n_cand = test_std_all.size();
  const std::size_t n_take = std::strtoull(a.get("--n", "500").c_str(), nullptr, 10);
  const std::vector<Sample> test_std = pick(test_std_all, n_take, srng);
  const std::vector<Sample> test_short = pick(make_samples(test_docs, 60, 260, 1, 3, srng), n_take, srng);
  if (test_std.size() < 100) {
    std::fprintf(stderr, "too few test samples (%zu)\n", test_std.size());
    return 1;
  }
  std::mt19937_64 crng(seed + 1);
  std::vector<std::pair<int, std::string>> sent_pool;
  for (const Sample& s : test_std)
    for (const std::string& x : split_sentences(s.text)) sent_pool.emplace_back(s.doc, x);

  // Slot order is v1's (it fixes the bootstrap seeds); model rungs from --model files follow.
  enum { R_HUMAN, R_TRIE, R_SS, R_WS, R_RL, R_RLET, R_REP, R_T06, R_T08, R_T10, R_SHORT, R_N };
  std::vector<Rung> rungs(R_N);
  const char* keys[R_N] = {"human", "trie", "sent_shuffled", "word_shuffled", "random_lexicon", "random_letters", "repeated_phrase",
                           "trie_T0.6", "trie_T0.8", "trie_T1.0", "human_short"};
  const char* names[R_N] = {"held-out human", "trie samples (pooled)", "sentences shuffled across docs", "words shuffled within sentences",
                            "random lexicon words", "random letters", "one phrase repeated", "trie samples T=0.6", "trie samples T=0.8",
                            "trie samples T=1.0", "held-out human, short (60-260 B)"};
  for (int i = 0; i < R_N; ++i) {
    rungs[static_cast<std::size_t>(i)].key = keys[i];
    rungs[static_cast<std::size_t>(i)].name = names[i];
  }
  for (const Sample& s : test_std) {
    rungs[R_HUMAN].texts.push_back(s.text);
    rungs[R_SS].texts.push_back(ctl_shuffle_sentences(s, sent_pool, crng));
    rungs[R_WS].texts.push_back(ctl_shuffle_words(s.text, crng));
    rungs[R_RL].texts.push_back(ctl_random_lexicon(s.text, c.model, crng));
    rungs[R_RLET].texts.push_back(ctl_random_letters(s.text, crng));
    rungs[R_REP].texts.push_back(ctl_repeat_phrase(s.text));
  }
  for (const Sample& s : test_short) rungs[R_SHORT].texts.push_back(s.text);
  GenSet gen;
  if (!a.get("--gen-trie").empty()) gen = load_gen_trie(a.get("--gen-trie"));
  for (std::size_t i = 0; i < gen.texts.size(); ++i) {
    rungs[R_TRIE].texts.push_back(gen.texts[i]);
    rungs[R_TRIE].kinds.push_back(gen.kinds[i]);
    rungs[R_TRIE].prompts.push_back(gen.prompts[i]);
    const int slot = gen.kinds[i] == "trie_T0.6" ? R_T06 : (gen.kinds[i] == "trie_T0.8" ? R_T08 : (gen.kinds[i] == "trie_T1.0" ? R_T10 : -1));
    if (slot >= 0) {
      rungs[static_cast<std::size_t>(slot)].texts.push_back(gen.texts[i]);
      rungs[static_cast<std::size_t>(slot)].prompts.push_back(gen.prompts[i]);
    }
  }
  // Model rungs: prepared JSONL files, one rung per "system".
  std::vector<std::size_t> model_rungs;
  for (const std::string& mf : a.multi_model) {
    std::map<std::string, std::size_t> slot;
    for (const JsonObj& j : read_jsonl(mf)) {
      const std::string sys = j.get("system", "model");
      auto it = slot.find(sys);
      if (it == slot.end()) {
        Rung r;
        r.key = sys;
        r.name = sys;
        rungs.push_back(std::move(r));
        it = slot.emplace(sys, rungs.size() - 1).first;
        model_rungs.push_back(it->second);
      }
      rungs[it->second].texts.push_back(j.get("text"));
      rungs[it->second].ids.push_back(j.get("id"));
      rungs[it->second].prompts.push_back(j.get("prompt"));
    }
  }
  for (Rung& r : rungs) {
    if (r.ids.empty())
      for (std::size_t i = 0; i < r.texts.size(); ++i) {
        char id[128];
        std::snprintf(id, sizeof id, "%s/%s/%04zu", label.c_str(), r.key.c_str(), i);
        r.ids.push_back(id);
      }
    r.feats.reserve(r.texts.size());
    for (const std::string& t : r.texts) r.feats.push_back(featurize(c, t));
    if (c.v3()) r.f3 = extract_v3_all(c.sm, c.px, r.texts, r.prompts, 4, false, c.v31());
  }
  std::fprintf(stderr, "[%.0fs] %s: features extracted\n", now_s() - g_t0, label.c_str());

  std::uint64_t bseed = 100 + seed % 1000;
  for (Rung& r : rungs) {
    for (std::size_t i = 0; i < r.feats.size(); ++i) {
      r.res.push_back(score_one(c, r.feats[i], r.texts[i], c.v3() ? &r.f3[i] : nullptr));
      r.scribe.push_back(r.res.back().headline(c.profile));
      r.surf.push_back(r.res.back().surface);
    }
    r.ci_scribe = bootstrap_mean_ci(r.scribe, 1000, ++bseed);
    bseed += 2;  // v1 drew two more intervals per rung here
    r.ci_surf = bootstrap_mean_ci(r.surf, 1000, ++bseed);
  }

  // ---- report
  std::printf("# SCRIBE %s ladder: %s (profile %s)\n\n", label.c_str(), a.get("--test").c_str(), c.profile.c_str());
  if (!g_dedup_note.empty()) std::printf("%s\n\n", g_dedup_note.c_str());
  std::printf("Pack %s: %zu docs, %zu bytes, lexicon %zu words, %zu trigrams; vectors: %s. Reference %s: %zu standard + %zu short samples (seed %llu). "
              "Test: %zu standard samples (of %zu candidates), %zu short (seed %llu%s).\n\n",
              a.get("--pack").c_str(), c.n_pack_docs, c.pack_bytes, c.model.vocab_size(), c.model.n_trigrams(),
              c.use_vectors ? a.get("--vectors").c_str() : "none", a.get("--ref").c_str(), c.n_ref_std, c.n_ref_short,
              static_cast<unsigned long long>(ref_seed), test_std.size(), n_cand, test_short.size(), static_cast<unsigned long long>(seed),
              a.has("--chain-rng") ? ", reference generator continued" : "");
  if (gen.lines)
    std::printf("Trie rung: %zu GEN lines, %zu kept after cleaning (%zu under 100 B dropped).\n\n", gen.lines, gen.texts.size(), gen.dropped);
  const double human_mean = mean_of(rungs[R_HUMAN].scribe);
  std::printf("## Rung means (95%% bootstrap interval of the mean, 1000 resamples)\n\n| rung | n | SCRIBE | parity | surface S | mean bytes |\n|---|---|---|---|---|---|\n");
  auto row = [&](const Rung& r) {
    if (r.feats.empty()) return;
    double by = 0;
    for (const Features& f : r.feats) by += static_cast<double>(f.bytes);
    std::printf("| %s | %zu | %s | %.2f | %s | %.0f |\n", r.name.c_str(), r.feats.size(), fmt_ci(mean_of(r.scribe), r.ci_scribe).c_str(),
                mean_of(r.scribe) / human_mean, fmt_ci(mean_of(r.surf), r.ci_surf).c_str(), by / static_cast<double>(r.feats.size()));
  };
  for (std::size_t i = 0; i < rungs.size(); ++i) row(rungs[i]);

  struct Chain {
    std::string name;
    std::vector<std::size_t> idx;
  };
  std::vector<Chain> chains;
  if (!rungs[R_TRIE].feats.empty()) {
    chains.push_back({"trie pooled", {R_HUMAN, R_TRIE, R_SS, R_WS, R_RL, R_RLET, R_REP}});
    for (int t : {R_T06, R_T08, R_T10})
      if (!rungs[static_cast<std::size_t>(t)].feats.empty())
        chains.push_back({rungs[static_cast<std::size_t>(t)].name, {R_HUMAN, static_cast<std::size_t>(t), R_SS, R_WS, R_RL, R_RLET, R_REP}});
  }
  chains.push_back({"control ladder (no model rung)", {R_HUMAN, R_SS, R_WS, R_RL, R_RLET, R_REP}});
  for (std::size_t m : model_rungs) chains.push_back({"model " + rungs[m].name, {R_HUMAN, m, R_SS, R_WS, R_RL, R_RLET, R_REP}});
  std::printf("\n## Ladders: pairwise ordering accuracy over all (upper, lower) pairs (ties = 1/2) and disjoint 95%% intervals; PASS needs both (accuracy >= 0.95)\n");
  std::vector<std::pair<std::string, std::vector<std::size_t>>> chain_idx;
  for (const Chain& ch : chains) chain_idx.emplace_back(ch.name, ch.idx);
  for (const Chain& ch : chains) {
    std::printf("\n### %s\n\n| upper > lower | SCRIBE acc | disjoint | | surface S acc | disjoint | |\n|---|---|---|---|---|---|---|\n", ch.name.c_str());
    int ps = 0, pu = 0, np = 0;
    for (std::size_t k = 0; k + 1 < ch.idx.size(); ++k) {
      const Rung &x = rungs[ch.idx[k]], &y = rungs[ch.idx[k + 1]];
      const double a1 = pairwise_accuracy(x.scribe, y.scribe), a2 = pairwise_accuracy(x.surf, y.surf);
      const bool d1 = x.ci_scribe.first > y.ci_scribe.second, d2 = x.ci_surf.first > y.ci_surf.second;
      const bool p1 = a1 >= 0.95 && d1, p2 = a2 >= 0.95 && d2;
      ps += p1;
      pu += p2;
      ++np;
      std::printf("| %s > %s | %.3f | %s | %s | %.3f | %s | %s |\n", x.name.c_str(), y.name.c_str(), a1, d1 ? "yes" : "no", p1 ? "PASS" : "FAIL", a2,
                  d2 ? "yes" : "no", p2 ? "PASS" : "FAIL");
    }
    std::printf("\nVerdict (%s): SCRIBE %s (%d of %d pairs), surface S %s (%d of %d pairs)\n", ch.name.c_str(), ps == np ? "PASS" : "FAIL", ps, np,
                pu == np ? "PASS" : "FAIL", pu, np);
  }
  // Axis profile of the headline profile.
  std::printf("\n## Axis profile (mean over samples)\n\n");
  if (c.profile == "v1") {
    std::printf("| rung | S | C (n) | I | S gate | I gate |\n|---|---|---|---|---|---|\n");
    for (const Rung& r : rungs) {
      if (r.feats.empty()) continue;
      double S = 0, C = 0, I = 0, g1 = 0, g2 = 0;
      int nc = 0;
      for (const Result& x : r.res) {
        S += x.v1.S;
        I += x.v1.I;
        g1 += x.v1.s_gate;
        g2 += x.v1.i_gate;
        if (x.v1.has_c) {
          C += x.v1.C;
          ++nc;
        }
      }
      const double n = static_cast<double>(r.res.size());
      std::printf("| %s | %.2f | %.2f (%d) | %.2f | %.0f%% | %.0f%% |\n", r.name.c_str(), S / n, nc ? C / nc : 0.0, nc, I / n, 100 * g1 / n, 100 * g2 / n);
    }
  } else {
    std::printf("%s", v2_profile_header().c_str());
    for (const Rung& r : rungs) {
      if (r.feats.empty()) continue;
      std::vector<ScoredV2> v;
      for (const Result& x : r.res) v.push_back(x.v2);
      std::printf("%s", v2_profile_row(r.name, v).c_str());
    }
  }
  // V4: correlation with length on human text.
  {
    auto by = [](const Rung& r) {
      std::vector<double> b;
      for (const Features& f : r.feats) b.push_back(static_cast<double>(f.bytes));
      return b;
    };
    std::vector<double> sc_all = rungs[R_HUMAN].scribe, by_all = by(rungs[R_HUMAN]);
    sc_all.insert(sc_all.end(), rungs[R_SHORT].scribe.begin(), rungs[R_SHORT].scribe.end());
    const std::vector<double> bs = by(rungs[R_SHORT]);
    by_all.insert(by_all.end(), bs.begin(), bs.end());
    std::printf("\n## V4: Pearson (Spearman) of SCRIBE with bytes on held-out human text\n\nstandard %.3f (%.3f); short %.3f (%.3f); pooled %.3f (%.3f). "
                "Mean SCRIBE standard %.3f, short %.3f.\n",
                pearson(rungs[R_HUMAN].scribe, by(rungs[R_HUMAN])), spearman(rungs[R_HUMAN].scribe, by(rungs[R_HUMAN])),
                pearson(rungs[R_SHORT].scribe, bs), spearman(rungs[R_SHORT].scribe, bs), pearson(sc_all, by_all), spearman(sc_all, by_all),
                mean_of(rungs[R_HUMAN].scribe), mean_of(rungs[R_SHORT].scribe));
  }
  if (c.v3()) print_v3_ladder(c, rungs, chain_idx, seed);
  // ---- export: every rung's texts and per-sample scores, and the reference statistics.
  const std::string dir = a.get("--export");
  if (!dir.empty()) {
    std::filesystem::create_directories(dir);
    std::ofstream ot(dir + "/texts.jsonl"), os(dir + "/scores.jsonl"), orf(dir + "/reference.jsonl");
    for (const Rung& r : rungs)
      for (std::size_t i = 0; i < r.texts.size(); ++i) {
        ot << text_line(r.ids[i], label, r.key, r.texts[i], "", "", r.kinds.empty() ? "" : "\"meta\":{\"kind\":\"" + json_escape(r.kinds[i]) + "\"}") << "\n";
        os << "{\"id\":\"" << json_escape(r.ids[i]) << "\",\"system\":\"" << json_escape(r.key) << "\","
           << result_json(r.feats[i], r.res[i], c.profile, c.v3() ? &r.f3[i] : nullptr) << "}\n";
      }
    for (std::size_t i = 0; i < c.ref_feats.size(); ++i)
      orf << "{\"id\":\"ref/" << i << "\",\"raw\":" << features_json(c.ref_feats[i]) << ",\"v2\":" << v2_json(c.v2.score(c.ref_feats[i])) << "}\n";
    if (c.v3()) export_v3_reference(c, dir);
    if (c.v3()) {  // v3 material: raw statistics with each word's surprisal (with and without the history, unigram)
      std::ofstream ov(dir + "/v3raw.jsonl");
      auto dump = [&](const std::string& id, const std::string& sys, const V3Features& f) {
        auto arr = [&](const char* k, const std::vector<float>& x) {
          ov << ",\"" << k << "\":[";
          for (std::size_t q = 0; q < x.size(); ++q) ov << (q ? "," : "") << num(x[q], 4);
          ov << "]";
        };
        ov << "{\"id\":\"" << json_escape(id) << "\",\"system\":\"" << json_escape(sys) << "\",\"bytes\":" << f.bytes;
        arr("s", f.seq.s);
        arr("s0", f.seq.s0);
        arr("su", f.seq.su);
        if (f.has_31) arr("fit", f.fit);
        ov << ",\"sent\":[";
        for (std::size_t k = 0; k < f.seq.sent.size(); ++k) ov << (k ? "," : "") << int(f.seq.sent[k]);
        ov << "],\"raw3\":" << v3_raw_json(f) << "}\n";
      };
      const std::vector<V3Features> rf = extract_v3_all(c.sm, c.px, c.ref_texts, {}, 4, true, c.v31());
      for (std::size_t i = 0; i < rf.size(); ++i) dump("ref/" + std::to_string(i), "ref", rf[i]);
      for (const Rung& r : rungs) {
        const std::vector<V3Features> v = extract_v3_all(c.sm, c.px, r.texts, r.prompts, 4, true, c.v31());
        for (std::size_t i = 0; i < v.size(); ++i) dump(r.ids[i], r.key, v[i]);
      }
    }
    std::fprintf(stderr, "exported to %s\n", dir.c_str());
  }
  std::fprintf(stderr, "[%.0fs] done\n", now_s() - g_t0);
  return 0;
}

// ===========================================================================
// score
// ===========================================================================

// Consecutive sentence windows covering a long text: a window closes before it would pass 600 bytes once it holds
// at least 300; a last window under 300 bytes joins the one before it. Each window is scored like a reference sample.
std::vector<std::string> text_windows(const std::string& text) {
  std::vector<std::string> w;
  std::string cur;
  for (const std::string& snt : split_sentences(scribe_detail::collapse_ws(collapse_newlines(text)))) {
    if (!cur.empty() && cur.size() + 1 + snt.size() > 600 && cur.size() >= 300) {
      w.push_back(cur);
      cur.clear();
    }
    if (!cur.empty()) cur.push_back(' ');
    cur += snt;
  }
  if (!cur.empty()) {
    if (cur.size() < 300 && !w.empty()) w.back() += " " + cur;
    else w.push_back(cur);
  }
  return w;
}

// windows --in F --out G: every text of F cut into its scoring windows (text_windows), prompt and fields kept; for
// building a prompted reference that matches --window scoring.
int cmd_windows(const Args& a) {
  std::ofstream o = open_out(a.get("--out"));
  std::size_t n = 0, w = 0;
  for (const JsonObj& j : read_jsonl(a.get("--in"))) {
    ++n;
    const std::vector<std::string> ws = text_windows(j.get("text"));
    for (std::size_t k = 0; k < ws.size(); ++k, ++w)
      o << text_line(j.get("id") + "/w" + std::to_string(k), j.get("set"), j.get("system"), ws[k], j.get("prompt"), j.get("ref")) << "\n";
  }
  std::fprintf(stderr, "%zu texts, %zu windows\n", n, w);
  return 0;
}

int cmd_score(const Args& a) {
  Ctx c;
  c.profile = a.get("--profile", "v2");
  const std::vector<std::string> pack_docs = load_docs(a.get("--pack"));
  const std::vector<std::string> ref_docs = load_docs(a.get("--ref"));
  set_v2_params(c, a.get("--v2"));
  set_v3_params(c, a.get("--v3"));
  build_pack(c, pack_docs, a.get("--vectors"));
  std::mt19937_64 rng(std::strtoull(a.get("--ref-seed", "20261027").c_str(), nullptr, 10));
  build_reference(c, ref_docs, rng, a.get("--ref-prompts"), a.has("--ref-whole"), std::strtoull(a.get("--ref-n", "0").c_str(), nullptr, 10));
  const std::vector<JsonObj> in = read_jsonl(a.get("--in"));
  std::ofstream o = open_out(a.get("--out"));
  const bool windowed = a.has("--window");
  const double t1 = now_s();
  for (const JsonObj& j : in) {
    const std::string text = j.get("text");
    const Features f = featurize(c, text, j.get("prompt"));
    V3Features f3;
    if (c.v3()) {
      const double tv = now_s();
      f3 = extract_v3(c.sm, c.px, text, j.get("prompt"), false, c.v31());
      g_t_v3 += now_s() - tv;
    }
    Result r = score_one(c, f, text, c.v3() ? &f3 : nullptr);
    std::string extra;
    if (windowed) {
      // The text's score is the mean over its windows; raw statistics stay those of the whole text.
      const std::vector<std::string> ws = text_windows(text);
      if (ws.size() > 1) {
        Result m;
        m.v1 = r.v1;
        double n = 0;
        for (const std::string& wt : ws) {
          V3Features w3;
          if (c.v3()) w3 = extract_v3(c.sm, c.px, wt, j.get("prompt"), false, c.v31());
          const Result x = score_one(c, featurize(c, wt, j.get("prompt")), wt, c.v3() ? &w3 : nullptr);
          m.v3.surprise += x.v3.surprise;
          m.v3.match += x.v3.match;
          m.v31.surprise += x.v31.surprise;
          m.v31.match += x.v31.match;
          m.v1.scribe += x.v1.scribe;
          m.v2.scribe += x.v2.scribe;
          m.surface += x.surface;
          m.v2.D += x.v2.D;
          m.v2.DL += x.v2.DL;
          m.v2.DS += x.v2.DS;
          m.v2.DC += x.v2.DC;
          m.v2.DI += x.v2.DI;
          m.v2.DR += x.v2.DR;
          m.v2.L += x.v2.L;
          m.v2.S += x.v2.S;
          m.v2.C += x.v2.C;
          m.v2.I += x.v2.I;
          m.v2.R += x.v2.R;
          n += 1;
        }
        m.v1.scribe = (m.v1.scribe - r.v1.scribe) / n;
        for (double* x : {&m.v2.scribe, &m.surface, &m.v2.D, &m.v2.DL, &m.v2.DS, &m.v2.DC, &m.v2.DI, &m.v2.DR, &m.v2.L, &m.v2.S, &m.v2.C, &m.v2.I, &m.v2.R})
          *x /= n;
        if (r.has_v3) {  // v3: the mean of the windows' SURPRISE and MATCH, combined with the windows' mean v2
          m.has_v3 = true;
          m.v3.surprise /= n;
          m.v3.match /= n;
          m.comb = combine_v3(m.v2.scribe, m.v3.surprise, m.v3.match, c.v3s.params.disagree);
        }
        if (r.has_v31) {  // v3.1: the same, with the v3.1 judges and the v3.1 combination
          m.has_v31 = true;
          m.v31.surprise /= n;
          m.v31.match /= n;
          m.score31 = combine_v31(m.v2.scribe, m.v31.surprise, m.v31.match, c.v31s.params.cp);
        }
        r = m;
      }
      extra = ",\"windows\":" + std::to_string(ws.size());
    }
    o << "{\"id\":\"" << json_escape(j.get("id")) << "\",\"system\":\"" << json_escape(j.get("system")) << "\"," << result_json(f, r, c.profile, c.v3() ? &f3 : nullptr)
      << extra << "}\n";
  }
  const double dt = now_s() - t1;
  std::fprintf(stderr, "[%.0fs] scored %zu texts in %.2f s (%.0f texts/s)\n", now_s() - g_t0, in.size(), dt, dt > 0 ? double(in.size()) / dt : 0.0);
  if (a.has("--timing"))
    std::fprintf(stderr,
                 "TIMING {\"pack_bytes\":%zu,\"pack_model_s\":%.3f,\"pack_v2_s\":%.3f,\"pack_vectors_s\":%.3f,\"n_featurised\":%zu,"
                 "\"extract_ms\":%.4f,\"extend_ms\":%.4f,\"v3_ms\":%.4f,\"score_texts\":%zu,\"score_s\":%.3f,\"texts_per_s\":%.1f,\"total_s\":%.2f}\n",
                 c.pack_bytes, g_t_pack_model, g_t_pack_v2, g_t_pack_vec, g_n_feat, 1000 * g_t_extract / std::max<std::size_t>(1, g_n_feat),
                 1000 * g_t_extend / std::max<std::size_t>(1, g_n_feat), 1000 * g_t_v3 / std::max<std::size_t>(1, in.size()), in.size(), dt,
                 dt > 0 ? double(in.size()) / dt : 0.0, now_s() - g_t0);
  return 0;
}

// ===========================================================================
// attacks (SCRIBE v3's battery; docs/reports/SCRIBE_V3.md)
// ===========================================================================

// v2's study used this paragraph for its generic attack (scripts/scribe_eval/attacks.py); v3 reuses it unchanged.
const char* kGenericParagraph =
    "This is a topic that has many different aspects. It is important to consider the wider context before reaching any conclusion. Experts "
    "have offered a range of views on the question over the years. In general, the answer depends on the situation and on the people involved. "
    "More research will be needed before the matter can be understood fully.";

// Candidate sentences for the co-occurrence attack: prose-like sentences of 40-300 bytes with at least 5 words, and the
// word-vector rows of their content words.
struct CoocPool {
  std::vector<std::string> sents;
  std::vector<std::vector<int>> rows;
};

CoocPool cooc_pool(const Ctx& c, const std::vector<std::string>& docs) {
  CoocPool p;
  std::vector<std::string> toks;
  std::unordered_set<std::string> seen;
  for (const std::string& d : docs)
    for (const std::string& s : split_sentences(d)) {
      if (s.size() < 40 || s.size() > 300 || !is_upper_a(static_cast<unsigned char>(s[0])) || !scribe_detail::ends_terminal(s)) continue;
      toks.clear();
      tokenize_words(s, toks);
      if (toks.size() < 5 || !seen.insert(s).second) continue;
      std::vector<int> r;
      for (const std::string& w : toks)
        if (c.v2.content_word(w)) {
          const int i = c.wv.index(w);
          if (i >= 0) r.push_back(i);
        }
      if (r.size() < 2) continue;
      p.sents.push_back(s);
      p.rows.push_back(std::move(r));
    }
  return p;
}

// The crude version of K5's gate: score every pool sentence by the mean, over its content words, of their cosine with
// the mean vector of the prompt's content words (PPMI-SVD vectors: co-occurrence); take the best sentences until the
// text holds 400-600 bytes and at least 3 sentences.
std::string cooc_select(const Ctx& c, const CoocPool& pool, const std::string& prompt) {
  std::vector<std::string> toks;
  for (const auto& t : sentence_tokens(prompt)) toks.insert(toks.end(), t.begin(), t.end());
  const std::size_t dim = c.wv.dim();
  std::vector<double> u(dim, 0.0);
  int nu = 0;
  for (const std::string& w : toks)
    if (c.v2.content_word(w)) {
      const int i = c.wv.index(w);
      if (i < 0) continue;
      const float* r = c.wv.row(i);
      for (std::size_t k = 0; k < dim; ++k) u[k] += r[k];
      ++nu;
    }
  if (nu == 0 || pool.sents.empty()) return "";
  std::vector<float> a(c.wv.size());
  for (std::size_t i = 0; i < a.size(); ++i) {
    const float* r = c.wv.row(static_cast<int>(i));
    double d = 0;
    for (std::size_t k = 0; k < dim; ++k) d += r[k] * u[k];
    a[i] = static_cast<float>(d / nu);
  }
  std::vector<std::pair<float, std::size_t>> sc(pool.sents.size());
  for (std::size_t j = 0; j < pool.sents.size(); ++j) {
    double s = 0;
    for (int i : pool.rows[j]) s += a[static_cast<std::size_t>(i)];
    sc[j] = {static_cast<float>(s / static_cast<double>(pool.rows[j].size())), j};
  }
  const std::size_t top = std::min<std::size_t>(200, sc.size());
  std::partial_sort(sc.begin(), sc.begin() + static_cast<std::ptrdiff_t>(top), sc.end(), [](const auto& x, const auto& y) { return x.first > y.first; });
  std::string out;
  int ns = 0;
  for (std::size_t k = 0; k < top && (out.size() < 400 || ns < 3); ++k) {
    const std::string& s = pool.sents[sc[k].second];
    if (out.size() + 1 + s.size() > 600) continue;
    if (!out.empty()) out.push_back(' ');
    out += s;
    ++ns;
  }
  return out;
}

// A white-space token without its leading and trailing ASCII punctuation.
std::string token_core(std::string w) {
  while (!w.empty() && !scribe_detail::is_alnum_a(static_cast<unsigned char>(w.back())) && static_cast<unsigned char>(w.back()) < 0x80) w.pop_back();
  std::size_t b = 0;
  while (b < w.size() && !scribe_detail::is_alnum_a(static_cast<unsigned char>(w[b])) && static_cast<unsigned char>(w[b]) < 0x80) ++b;
  return w.substr(b);
}

// The prompt's content words as written (punctuation stripped), rarest in the pack first (rarest = false: most
// frequent first), at most 5, no repeats. rarity: the word's rarity in the pack (ScribeV2Scorer::rarity).
template <class Rarity, class Content>
std::vector<std::string> prompt_keywords_by(const std::string& prompt, Rarity rarity, Content content, bool rarest = true, bool lower_only = false) {
  std::vector<std::pair<double, std::string>> v;
  std::unordered_set<std::string> seen;
  for (const std::string& tok : split_ws(prompt)) {
    const std::string w = token_core(tok);
    if (lower_only && (w.empty() || w[0] < 'a' || w[0] > 'z')) continue;
    std::vector<std::string> t;
    tokenize_words(w, t);
    if (t.size() != 1 || w.size() < 3 || !content(t[0]) || !seen.insert(t[0]).second) continue;
    v.emplace_back(rarest ? -rarity(t[0]) : rarity(t[0]), w);
  }
  std::sort(v.begin(), v.end());
  std::vector<std::string> out;
  for (std::size_t i = 0; i < v.size() && out.size() < 5; ++i) out.push_back(v[i].second);
  if (out.empty()) out.push_back("it");
  return out;
}
std::vector<std::string> prompt_keywords(const Ctx& c, const std::string& prompt, bool rarest = true) {
  return prompt_keywords_by(
      prompt, [&](const std::string& w) { return c.v2.rarity(w); }, [&](const std::string& w) { return c.v2.content_word(w); }, rarest);
}

// Inserts the keywords (cycling) after every `every`-th word of text (the registered attacks: every 4th).
std::string stuff_keywords(const std::string& text, const std::vector<std::string>& kw, std::size_t every = 4) {
  std::vector<std::string> w = split_ws(text), o;
  std::size_t k = 0;
  for (std::size_t i = 0; i < w.size(); ++i) {
    o.push_back(w[i]);
    if (i % every == every - 1 && i + 1 < w.size()) o.push_back(kw[k++ % kw.size()]);
  }
  return join(o);
}

// ---- Held-out attacks (SCRIBE v3.1, docs/reports/SCRIBE_V31.md). Written and registered before any v3.1 design
// work; built only with `attacks --heldout`, which was never run on development data (selftest checks their
// construction on toy strings).

// The keywords (cycling) inserted at random places: after a gap of 2 to 8 words (uniform, mean 5).
std::string stuff_random(const std::string& text, const std::vector<std::string>& kw, std::mt19937_64& rng) {
  std::vector<std::string> w = split_ws(text), o;
  std::uniform_int_distribution<int> gap(2, 8);
  std::size_t k = 0;
  int next = gap(rng);
  for (std::size_t i = 0; i < w.size(); ++i) {
    o.push_back(w[i]);
    if (--next == 0 && i + 1 < w.size()) {
      o.push_back(kw[k++ % kw.size()]);
      next = gap(rng);
    }
  }
  return join(o);
}

// Four more generic paragraphs (none of v2's), used in turn.
const char* kGenericParagraphs2[4] = {
    "There are many things to say about this subject. Some of them are well known, while others are less clear. People who have looked at it "
    "closely tend to agree on the main points. Still, there is room for different opinions on the details. Over time, our understanding of it "
    "has changed a great deal.",
    "The history of this subject is long and complex. Over the years, many people have contributed to its development in different ways. Some "
    "of these contributions were important, while others had only a small effect. Today it is still discussed by researchers and by the "
    "general public. Its future will depend on many factors.",
    "It is often said that the most important things are also the simplest. This idea can be applied in many areas of life. When we look more "
    "closely, however, things are rarely as simple as they first appear. Each case has its own features that must be taken into account. In "
    "the end, careful thought is always required.",
    "Many people have an interest in this area for a variety of reasons. For some, it is a matter of personal experience, and for others it is "
    "part of their work. Either way, it raises questions that are worth asking. The answers are not always easy to find. Nevertheless, the "
    "effort to understand it is usually rewarded."};

// Capitalised tokens of a text that do not start a sentence (cores), most frequent first (ties: first seen).
std::vector<std::string> text_entities(const std::string& text) {
  std::vector<std::string> order;
  std::unordered_map<std::string, int> cnt;
  for (const std::string& s : split_sentences(text)) {
    const std::vector<std::string> w = split_ws(s);
    for (std::size_t i = 1; i < w.size(); ++i) {
      const std::string core = token_core(w[i]);
      if (core.size() < 2 || !is_upper_a(static_cast<unsigned char>(core[0]))) continue;
      if (cnt[core]++ == 0) order.push_back(core);
    }
  }
  std::stable_sort(order.begin(), order.end(), [&](const std::string& x, const std::string& y) { return cnt[x] > cnt[y]; });
  return order;
}

// A fixed template with the prompt's entities (E1, E2: its most frequent capitalised words) and rare lowercase content
// words (N1, N2) swapped in.
std::string template_text(const std::vector<std::string>& ents, const std::vector<std::string>& rare_lower) {
  std::string e1 = ents.empty() ? std::string() : ents[0], e2 = ents.size() > 1 ? ents[1] : e1;
  const std::string n1 = !rare_lower.empty() ? rare_lower[0] : "history", n2 = rare_lower.size() > 1 ? rare_lower[1] : "culture";
  if (e1.empty()) {
    e1 = n1;
    if (!e1.empty() && e1[0] >= 'a' && e1[0] <= 'z') e1[0] = static_cast<char>(e1[0] - 32);
    e2 = e1;
  }
  return e1 + " is one of the best known examples of its kind. It is closely linked with " + e2 + ", and it is often discussed together with " + n1 +
         ". Many writers have described " + e1 + " as an important part of the story of " + e2 + ". Its role in " + n2 +
         " has been studied for many years, and new work on " + n1 + " continues to appear. Today " + e1 + " is still widely known.";
}

// The true continuation's sentences with the prompt's sentences scattered between them: c1 p1 c2 p2 ... (the prompt's
// sentences cycle), stopping before 600 bytes.
std::string echo_scatter(const std::string& prompt, const std::string& cont) {
  const std::vector<std::string> ps = split_sentences(prompt), cs = split_sentences(cont);
  std::string out;
  std::size_t pi = 0;
  for (const std::string& x : cs) {
    for (const std::string* s : {&x, ps.empty() ? nullptr : &ps[pi % ps.size()]}) {
      if (!s) continue;
      if (!out.empty() && out.size() + 1 + s->size() > 600) return out;
      out += (out.empty() ? "" : " ") + *s;
    }
    ++pi;
  }
  return out;
}

// Another document's continuation with its own title entity (its most frequent capitalised word) replaced, wherever
// it is a whole token, by the prompt's.
std::string title_swap(const std::string& other, const std::string& prompt) {
  const std::vector<std::string> eo = text_entities(other), ep = text_entities(prompt);
  if (eo.empty() || ep.empty()) return other;
  std::vector<std::string> w = split_ws(other);
  for (std::string& t : w) {
    const std::string core = token_core(t);
    if (core != eo[0]) continue;
    const std::size_t at = t.find(core);
    t = t.substr(0, at) + ep[0] + t.substr(at + core.size());
  }
  return join(w);
}

// A fluent list of loosely related sentences: from other documents' sentences (pool: document, sentence), those that
// share the most content words with the prompt (each shared word counts its rarity), at most one per document,
// in that order until the text holds 400 bytes and 3 sentences (never over 600).
template <class Rarity, class Content>
std::string list_related(const std::string& prompt, int doc, const std::vector<std::pair<int, std::string>>& pool, Rarity rarity, Content content) {
  std::unordered_set<std::string> pw;
  for (const auto& t : sentence_tokens(prompt))
    for (const std::string& w : t)
      if (content(w)) pw.insert(w);
  std::vector<std::pair<double, std::size_t>> sc;
  for (std::size_t j = 0; j < pool.size(); ++j) {
    if (pool[j].first == doc) continue;
    std::unordered_set<std::string> seen;
    double s = 0;
    for (const auto& t : sentence_tokens(pool[j].second))
      for (const std::string& w : t)
        if (pw.count(w) && seen.insert(w).second) s += rarity(w);
    if (s > 0) sc.emplace_back(-s, j);
  }
  std::sort(sc.begin(), sc.end());
  std::string out;
  int ns = 0;
  std::unordered_set<int> used;
  for (const auto& x : sc) {
    if (out.size() >= 400 && ns >= 3) break;
    const auto& p = pool[x.second];
    if (used.count(p.first) || out.size() + 1 + p.second.size() > 600) continue;
    used.insert(p.first);
    out += (out.empty() ? "" : " ") + p.second;
    ++ns;
  }
  return out;
}

// The battery's report in profile v31: every attack x judge (v3's three and mean, and v3.1's two judges and
// combination); the registered rule for v3.1 (P(human > attack) >= 0.95 under v3.1 for each registered attack); the
// held-out attacks with pass or fail at 0.95 (no rule).
int attacks_report_v31(const Args& a, const Ctx& c, const std::string& label, std::uint64_t seed, std::size_t N, std::size_t n_cp, std::size_t n_co,
                       const std::vector<std::string>& names, std::size_t n_registered, std::size_t n_before_heldout,
                       const std::vector<std::vector<std::string>>& T, const std::vector<PromptPair>& pairs,
                       const std::vector<std::array<std::vector<double>, 7>>& S, const std::vector<std::vector<Result>>& res,
                       const std::vector<std::vector<Features>>& feats, const std::vector<std::vector<V3Features>>& f3) {
  const char* mname[7] = {"v2", "SURPRISE", "MATCH", "v3", "SURPRISE 3.1", "MATCH 3.1", "v3.1"};
  std::printf("# SCRIBE v3.1 attack battery: %s (%s)\n\n", label.c_str(), a.get("--test").c_str());
  if (!g_dedup_note.empty()) std::printf("%s\n\n", g_dedup_note.c_str());
  std::printf("%zu prompt / continuation pairs (seed %llu), one per document; every attack built from them; scored with the prompt (v2: open "
              "profile). Pack %s, reference %s, co-occurrence pools: %zu pack sentences, %zu outside (%s). v3.1 = power mean (exponent %g) of v2, "
              "SURPRISE 3.1 and MATCH 3.1.\n\n",
              N, static_cast<unsigned long long>(seed), a.get("--pack").c_str(), a.get("--ref").c_str(), n_cp, n_co, a.get("--outside", "none").c_str(),
              c.v31s.params.cp);
  std::printf("Mean score (P(human > attack) over all pairs, ties 1/2). Caught: the judge ranks human text above the attack with accuracy >= 0.95. "
              "Rule (registered attacks): v3.1 >= 0.95. Held-out attacks: pass or fail at 0.95, no rule.\n\n");
  std::printf("| attack | n | v2 | SURPRISE | MATCH | v3 | SURPRISE 3.1 | MATCH 3.1 | v3.1 | caught by | v3.1 |\n|---|---|---|---|---|---|---|---|---|---|---|\n");
  int rule_ok = 0, rule_n = 0, v3_ok = 0, ho_ok = 0, ho_n = 0;
  for (std::size_t k = 0; k < names.size(); ++k) {
    if (S[k][0].empty()) continue;
    const bool reg = k < n_registered, ho = k >= n_before_heldout;
    std::printf("| %s%s | %zu", names[k].c_str(), reg ? "" : ho ? " (held-out)" : " (extra)", S[k][0].size());
    double accs[7];
    for (int m = 0; m < 7; ++m) {
      const double mu = mean_of(S[k][static_cast<std::size_t>(m)]);
      if (k == 0) {
        std::printf(" | %.3f", mu);
        continue;
      }
      accs[m] = pairwise_accuracy(S[0][static_cast<std::size_t>(m)], S[k][static_cast<std::size_t>(m)]);
      std::printf(" | %.3f (%.3f)", mu, accs[m]);
    }
    if (k == 0) {
      std::printf(" | | |\n");
      continue;
    }
    std::string by;
    for (int m : {0, 1, 2, 4, 5})
      if (accs[m] >= 0.95) by += std::string(by.empty() ? "" : ", ") + mname[m];
    const bool ok = accs[6] >= 0.95;
    if (reg) {
      ++rule_n;
      rule_ok += ok;
      v3_ok += accs[3] >= 0.95 && (accs[1] >= 0.95 || accs[2] >= 0.95);
    } else if (ho) {
      ++ho_n;
      ho_ok += ok;
    }
    std::printf(" | %s | %s |\n", by.empty() ? "none" : by.c_str(), reg || ho ? (ok ? "PASS" : "FAIL") : "(reported only)");
  }
  std::printf("\nRule (v3.1): %d of %d registered attacks pass. (v3's rule on the same battery: %d of %d.)\n", rule_ok, rule_n, v3_ok, rule_n);
  if (ho_n) std::printf("Held-out attacks (v3.1 at 0.95, no rule): %d of %d pass.\n", ho_ok, ho_n);
  std::printf("\nDeviance terms of the v3.1 judges (mean over texts; F foreign words, B bland):\n\n| attack | SURPRISE 3.1 D_L | D_S | D_C | D_P | D_F | D_B | MATCH 3.1 D_L | D_S "
              "| D_C | D_P | D_F | D_B | v2 D_L | D_S | D_C | D_I |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n");
  for (std::size_t k = 0; k < names.size(); ++k) {
    if (res[k].empty()) continue;
    double g[2][6] = {}, v2g[4] = {};
    for (const Result& r : res[k]) {
      for (int m = 0; m < 2; ++m)
        for (int q = 0; q < 6; ++q) g[m][q] += r.v31.Dg[m][q];
      v2g[0] += r.v2.DL;
      v2g[1] += r.v2.DS;
      v2g[2] += r.v2.DC;
      v2g[3] += r.v2.DI;
    }
    const double nn = static_cast<double>(res[k].size());
    std::printf("| %s", names[k].c_str());
    for (int m = 0; m < 2; ++m)
      for (int q = 0; q < 6; ++q) std::printf(" | %.2f", g[m][q] / nn);
    for (int q = 0; q < 4; ++q) std::printf(" | %.2f", v2g[q] / nn);
    std::printf(" |\n");
  }
  const std::string dir = a.get("--export");
  if (!dir.empty()) {
    std::filesystem::create_directories(dir);
    export_v3_reference(c, dir);
    std::ofstream ot(dir + "/texts.jsonl"), os(dir + "/scores.jsonl");
    for (std::size_t k = 0; k < names.size(); ++k)
      for (std::size_t i = 0; i < res[k].size(); ++i) {
        char id[96];
        std::snprintf(id, sizeof id, "%s/%s/%04zu", label.c_str(), names[k].c_str(), i);
        ot << text_line(id, label, names[k], T[k][i], pairs[i].prompt) << "\n";
        os << "{\"id\":\"" << json_escape(id) << "\",\"system\":\"" << json_escape(names[k]) << "\"," << result_json(feats[k][i], res[k][i], "v31", &f3[k][i])
           << "}\n";
      }
    std::fprintf(stderr, "exported to %s\n", dir.c_str());
  }
  std::fprintf(stderr, "[%.0fs] done\n", now_s() - g_t0);
  return rule_ok == rule_n ? 0 : 3;
}

int cmd_attacks(const Args& a) {
  Ctx c;
  c.profile = a.get("--profile", "v3");
  if (c.profile != "v3" && c.profile != "v31") {
    std::fprintf(stderr, "attacks takes --profile v3 or v31\n");
    return 2;
  }
  const bool heldout = a.has("--heldout");
  const std::string label = a.get("--label", "attacks");
  const std::uint64_t ref_seed = std::strtoull(a.get("--ref-seed", "20261027").c_str(), nullptr, 10);
  const std::uint64_t seed = std::strtoull(a.get("--seed", "31415926").c_str(), nullptr, 10);
  const std::size_t n = std::strtoull(a.get("--n", "200").c_str(), nullptr, 10);
  const std::vector<std::string> pack_docs = load_docs(a.get("--pack"));
  const std::vector<std::string> ref_docs = load_docs(a.get("--ref"));
  std::vector<std::string> test_docs = load_docs(a.get("--test"));
  if (a.has("--dedup")) g_dedup_note = apply_dedup(test_docs, pack_docs, ref_docs);
  if (a.get("--vectors").empty()) {
    std::fprintf(stderr, "attacks needs --vectors (the co-occurrence attack and v2's coherence read them)\n");
    return 2;
  }
  set_v2_params(c, a.get("--v2"));
  set_v3_params(c, a.get("--v3"));
  build_pack(c, pack_docs, a.get("--vectors"));
  std::mt19937_64 rrng(ref_seed);
  build_reference(c, ref_docs, rrng);
  std::mt19937_64 rng(seed);
  const std::vector<PromptPair> pairs = make_prompt_pairs(test_docs, n, rng);
  const std::size_t N = pairs.size();
  if (N < 50) {
    std::fprintf(stderr, "too few prompts (%zu)\n", N);
    return 1;
  }
  // Pack samples to copy, a derangement for "another document", and the sentence pool for the shuffle.
  std::vector<Sample> copies = pick(make_samples(pack_docs, 400, 600, 3, 1, rng), N, rng);
  std::vector<std::size_t> perm(N);
  std::iota(perm.begin(), perm.end(), std::size_t{0});
  std::shuffle(perm.begin(), perm.end(), rng);
  for (std::size_t i = 0; i < N; ++i)
    if (perm[i] == i) std::swap(perm[i], perm[(i + 1) % N]);
  std::vector<std::pair<int, std::string>> pool;
  for (const PromptPair& p : pairs)
    for (const std::string& x : split_sentences(p.cont)) pool.emplace_back(p.doc, x);
  const double tp = now_s();
  const CoocPool cp = cooc_pool(c, pack_docs);
  CoocPool co;
  if (!a.get("--outside").empty()) co = cooc_pool(c, load_docs(a.get("--outside")));
  std::fprintf(stderr, "[%.0fs] co-occurrence pools: %zu pack sentences, %zu outside (%.1f s)\n", now_s() - g_t0, cp.sents.size(), co.sents.size(), now_s() - tp);
  // Registered attacks first; the extras (reported only) after them; with --heldout, v3.1's held-out attacks last.
  std::vector<std::string> names = {"human",         "copy_pack", "echo_repeat", "echo_copy", "stuff_human", "stuff_generic", "loop",
                                    "generic",       "shuffle_docs", "cooc_pack", "reorder",   "cooc_out",    "offprompt"};
  const std::size_t n_registered = 10;  // human + 9 attacks
  const std::size_t n_before_heldout = names.size();
  if (heldout)
    for (const char* h : {"ho_stuff7_rare", "ho_stuff3_freq", "ho_stuff_rand", "ho_generic2", "ho_template", "ho_echo_scatter", "ho_title_swap",
                          "ho_list_related"})
      names.push_back(h);
  std::vector<std::vector<std::string>> T(names.size(), std::vector<std::string>(N));
  std::vector<std::string> cooc_p(N), cooc_o(N);
  {
    std::atomic<std::size_t> next{0};
    auto work = [&]() {
      for (std::size_t i; (i = next++) < N;) {
        cooc_p[i] = cooc_select(c, cp, pairs[i].prompt);
        if (!co.sents.empty()) cooc_o[i] = cooc_select(c, co, pairs[i].prompt);
      }
    };
    std::vector<std::thread> th;
    for (int k = 1; k < 4; ++k) th.emplace_back(work);
    work();
    for (std::thread& x : th) x.join();
  }
  std::mt19937_64 arng(seed + 7);
  for (std::size_t i = 0; i < N; ++i) {
    const PromptPair& p = pairs[i];
    const std::vector<std::string> kw = prompt_keywords(c, p.prompt);
    const std::vector<std::string> cs = split_sentences(p.cont);
    std::string echo = p.prompt;
    while (echo.size() < p.cont.size()) echo += " " + p.prompt;
    std::string ecopy = p.prompt;
    for (const std::string& x : cs) {
      if (ecopy.size() + 1 + x.size() > 600) break;
      ecopy += " " + x;
    }
    std::string loop;
    const std::string two = cs.size() >= 2 ? cs[0] + " " + cs[1] : p.cont;
    while (loop.size() < p.cont.size()) loop += (loop.empty() ? "" : " ") + two;
    std::vector<std::string> ro = cs;
    for (int tries = 0; tries < 10 && ro == cs; ++tries) std::shuffle(ro.begin(), ro.end(), arng);
    T[0][i] = p.cont;
    T[1][i] = copies[i % copies.size()].text;
    T[2][i] = echo;
    T[3][i] = ecopy;
    T[4][i] = stuff_keywords(pairs[perm[i]].cont, kw);
    T[5][i] = stuff_keywords(kGenericParagraph, kw);
    T[6][i] = loop;
    T[7][i] = kGenericParagraph;
    T[8][i] = ctl_shuffle_sentences(Sample{p.cont, p.doc}, pool, arng);
    T[9][i] = cooc_p[i];
    T[10][i] = join(ro);
    T[11][i] = cooc_o[i];
    T[12][i] = pairs[perm[i]].cont;
  }
  if (heldout) {  // a generator of their own, so the registered texts above do not change
    std::mt19937_64 hrng(seed + 101);
    std::vector<std::size_t> perm2(N);
    std::iota(perm2.begin(), perm2.end(), std::size_t{0});
    std::shuffle(perm2.begin(), perm2.end(), hrng);
    for (std::size_t i = 0; i < N; ++i)
      if (perm2[i] == i) std::swap(perm2[i], perm2[(i + 1) % N]);
    auto rar = [&](const std::string& w) { return c.v2.rarity(w); };
    auto con = [&](const std::string& w) { return c.v2.content_word(w); };
    const std::size_t h = n_before_heldout;
    for (std::size_t i = 0; i < N; ++i) {
      const PromptPair& p = pairs[i];
      const std::string& other = pairs[perm2[i]].cont;
      const std::vector<std::string> rare = prompt_keywords(c, p.prompt, true), freq = prompt_keywords(c, p.prompt, false);
      std::vector<std::string> rare_lower = prompt_keywords_by(p.prompt, rar, con, true, true);
      if (rare_lower.size() == 1 && rare_lower[0] == "it") rare_lower.clear();
      T[h + 0][i] = stuff_keywords(other, rare, 7);
      T[h + 1][i] = stuff_keywords(other, freq, 3);
      T[h + 2][i] = stuff_random(other, rare, hrng);
      T[h + 3][i] = kGenericParagraphs2[i % 4];
      T[h + 4][i] = template_text(text_entities(p.prompt), rare_lower);
      T[h + 5][i] = echo_scatter(p.prompt, p.cont);
      T[h + 6][i] = title_swap(other, p.prompt);
      T[h + 7][i] = list_related(p.prompt, p.doc, pool, rar, con);
      if (T[h + 7][i].empty()) T[h + 7][i] = other;  // no sentence shares a content word with the prompt
    }
  }
  // Score: v2 open profile (no prompt), v3 with the prompt.
  std::vector<std::string> prompts(N);
  for (std::size_t i = 0; i < N; ++i) prompts[i] = pairs[i].prompt;
  std::vector<std::array<std::vector<double>, 7>> S(names.size());
  std::vector<std::vector<Result>> res(names.size());
  std::vector<std::vector<Features>> feats(names.size());
  std::vector<std::vector<V3Features>> f3(names.size());
  for (std::size_t k = 0; k < names.size(); ++k) {
    if (T[k][0].empty() && k >= n_registered) continue;  // an extra that was not built
    f3[k] = extract_v3_all(c.sm, c.px, T[k], prompts, 4, false, c.v31());
    for (std::size_t i = 0; i < N; ++i) {
      feats[k].push_back(featurize(c, T[k][i]));
      res[k].push_back(score_one(c, feats[k][i], T[k][i], &f3[k][i]));
      const Result& r = res[k].back();
      S[k][0].push_back(r.v2.scribe);
      S[k][1].push_back(r.v3.surprise);
      S[k][2].push_back(r.v3.match);
      S[k][3].push_back(r.comb.v3);
      if (c.v31()) {
        S[k][4].push_back(r.v31.surprise);
        S[k][5].push_back(r.v31.match);
        S[k][6].push_back(r.score31);
      }
    }
  }
  if (c.v31()) return attacks_report_v31(a, c, label, seed, N, cp.sents.size(), co.sents.size(), names, n_registered, n_before_heldout, T, pairs, S, res,
                                         feats, f3);
  const char* mname[4] = {"v2", "SURPRISE", "MATCH", "v3"};
  std::printf("# SCRIBE v3 attack battery: %s (%s)\n\n", label.c_str(), a.get("--test").c_str());
  if (!g_dedup_note.empty()) std::printf("%s\n\n", g_dedup_note.c_str());
  std::printf("%zu prompt / continuation pairs (seed %llu), one per document; every attack built from them; scored with the prompt (v2: open "
              "profile). Pack %s, reference %s, co-occurrence pools: %zu pack sentences, %zu outside (%s).\n\n",
              N, static_cast<unsigned long long>(seed), a.get("--pack").c_str(), a.get("--ref").c_str(), cp.sents.size(), co.sents.size(),
              a.get("--outside", "none").c_str());
  std::printf("Mean score (P(human > attack) over all pairs, ties 1/2). Caught: the judge ranks human text above the attack with "
              "accuracy >= 0.95. Rule (registered attacks): v3 >= 0.95 and caught by SURPRISE or MATCH.\n\n");
  std::printf("| attack | n | v2 | SURPRISE | MATCH | v3 | caught by | rule |\n|---|---|---|---|---|---|---|---|\n");
  int rule_ok = 0, rule_n = 0;
  for (std::size_t k = 0; k < names.size(); ++k) {
    if (S[k][0].empty()) continue;
    std::printf("| %s%s | %zu", names[k].c_str(), k >= n_registered ? " (extra)" : "", S[k][0].size());
    double accs[4];
    for (int m = 0; m < 4; ++m) {
      const double mu = mean_of(S[k][static_cast<std::size_t>(m)]);
      if (k == 0) {
        std::printf(" | %.3f", mu);
        continue;
      }
      accs[m] = pairwise_accuracy(S[0][static_cast<std::size_t>(m)], S[k][static_cast<std::size_t>(m)]);
      std::printf(" | %.3f (%.3f)", mu, accs[m]);
    }
    if (k == 0) {
      std::printf(" | | |\n");
      continue;
    }
    std::string by;
    for (int m = 0; m < 3; ++m)
      if (accs[m] >= 0.95) by += std::string(by.empty() ? "" : ", ") + mname[m];
    const bool ok = accs[3] >= 0.95 && (accs[1] >= 0.95 || accs[2] >= 0.95);
    if (k < n_registered) {
      ++rule_n;
      rule_ok += ok;
    }
    std::printf(" | %s | %s |\n", by.empty() ? "none" : by.c_str(), k < n_registered ? (ok ? "PASS" : "FAIL") : "(reported only)");
  }
  std::printf("\nRule: %d of %d registered attacks pass.\n", rule_ok, rule_n);
  // Deviance terms per attack.
  std::printf("\n| attack | SURPRISE D_L | D_S | D_C | D_P | MATCH D_L | D_S | D_C | D_P | v2 D_L | D_S | D_C | D_I | disagree |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n");
  for (std::size_t k = 0; k < names.size(); ++k) {
    if (res[k].empty()) continue;
    double g[2][4] = {}, v2g[4] = {}, dis = 0;
    for (const Result& r : res[k]) {
      for (int m = 0; m < 2; ++m)
        for (int q = 0; q < 4; ++q) g[m][q] += r.v3.Dg[m][q];
      v2g[0] += r.v2.DL;
      v2g[1] += r.v2.DS;
      v2g[2] += r.v2.DC;
      v2g[3] += r.v2.DI;
      dis += r.comb.disagree;
    }
    const double nn = static_cast<double>(res[k].size());
    std::printf("| %s", names[k].c_str());
    for (int m = 0; m < 2; ++m)
      for (int q = 0; q < 4; ++q) std::printf(" | %.2f", g[m][q] / nn);
    for (int q = 0; q < 4; ++q) std::printf(" | %.2f", v2g[q] / nn);
    std::printf(" | %.0f%% |\n", 100 * dis / nn);
  }
  const std::string dir = a.get("--export");
  if (!dir.empty()) {
    std::filesystem::create_directories(dir);
    export_v3_reference(c, dir);
    std::ofstream ot(dir + "/texts.jsonl"), os(dir + "/scores.jsonl");
    for (std::size_t k = 0; k < names.size(); ++k)
      for (std::size_t i = 0; i < res[k].size(); ++i) {
        char id[96];
        std::snprintf(id, sizeof id, "%s/%s/%04zu", label.c_str(), names[k].c_str(), i);
        ot << text_line(id, label, names[k], T[k][i], pairs[i].prompt) << "\n";
        os << "{\"id\":\"" << json_escape(id) << "\",\"system\":\"" << json_escape(names[k]) << "\"," << result_json(feats[k][i], res[k][i], "v3", &f3[k][i])
           << "}\n";
      }
    std::fprintf(stderr, "exported to %s\n", dir.c_str());
  }
  std::fprintf(stderr, "[%.0fs] done\n", now_s() - g_t0);
  return rule_ok == rule_n ? 0 : 3;
}

// ===========================================================================
// selftest
// ===========================================================================

int g_fail = 0, g_checks = 0;
#define CHECK(cond)                                               \
  do {                                                            \
    ++g_checks;                                                   \
    if (!(cond)) {                                                \
      ++g_fail;                                                   \
      std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); \
    }                                                             \
  } while (0)
#define CHECK_NEAR(x, y, tol)                                                                  \
  do {                                                                                         \
    ++g_checks;                                                                                \
    const double _x = (x), _y = (y);                                                           \
    if (!(std::fabs(_x - _y) <= (tol))) {                                                      \
      ++g_fail;                                                                                \
      std::printf("FAIL %s:%d  %s = %.10g, expected %.10g\n", __FILE__, __LINE__, #x, _x, _y); \
    }                                                                                          \
  } while (0)

int selftest() {
  // ---- v0 and v1 checks (unchanged) -----------------------------------------------------
  const std::string raw =
      "'''Rome''' is the [[capital city|capital]] of [[Italy]] and a major European city.&lt;ref&gt;Some ref&lt;/ref&gt; "
      "{{cite web|url=x}} It has [[Image:Foo.jpg|thumb|A [[nested]] caption]] many old buildings and wide squares.\n"
      "== History ==\n* a list item that is long enough to be a line but starts with a star sign okay\n"
      "{| class=\"wikitable\"\n| cell\n|}\n"
      "Another paragraph about the city of Rome with enough words to count as prose here.&amp;nbsp;";
  CHECK(clean_wiki_body(raw) ==
        "Rome is the capital of Italy and a major European city. It has many old buildings and wide squares. "
        "Another paragraph about the city of Rome with enough words to count as prose here.");
  const std::string page = "<page><title>X</title><revision><text xml:space=\"preserve\">" + raw + "</text></revision></page>"
                           "<page><title>R</title><revision><text>#REDIRECT [[X]]</text></revision></page>"
                           "<page><title>cut</title><revision><text>Unfinished";
  CHECK(clean_wiki_documents(page.data(), page.size()).size() == 1);
  const std::vector<std::string> ss = split_sentences("Mr. Smith went to Washington. He liked it! Did he? J. R. Tolkien wrote books.");
  CHECK(ss.size() == 4 && ss[0] == "Mr. Smith went to Washington." && ss[3] == "J. R. Tolkien wrote books.");
  CHECK(split_sentences("It ended. then lower case began.").size() == 2);
  std::vector<std::string> tk;
  tokenize_words("Rose's 1,000 don't U.S. cars-and-trucks", tk);
  CHECK((tk == std::vector<std::string>{"rose", "'s", "1,000", "don't", "u", "s", "cars", "and", "trucks"}));
  CHECK(numeric_token("1,000") && numeric_token("1980s") && !numeric_token("abc") && !numeric_token("3d"));
  CHECK_NEAR(jsd_bits({1, 0}, {0, 1}), 1.0, 1e-12);
  CHECK_NEAR(jsd_bits({0.5, 0.5}, {0.5, 0.5}), 0.0, 1e-12);
  CHECK_NEAR(jsd_bits({0.5, 0.5}, {1, 0}), 0.311278, 1e-5);
  Ecdf e;
  for (int i = 1; i <= 100; ++i) e.add(i);
  e.finish();
  CHECK_NEAR(e.F(50.5), 0.5, 1e-12);
  CHECK_NEAR(e.one_sided(50.5), 1.0, 1e-12);
  CHECK_NEAR(e.two_sided(0.0), 1.0 / 101.0, 1e-12);
  CHECK_NEAR(e.one_sided(1000.0), 1.0, 1e-12);
  CHECK_NEAR(pairwise_accuracy({3}, {1, 2, 3}), 2.5 / 3.0, 1e-12);
  CHECK_NEAR(pearson({1, 2, 3, 4}, {2, 4, 6, 8}), 1.0, 1e-12);
  CHECK_NEAR(spearman({1, 2, 3, 4}, {1, 8, 27, 64}), 1.0, 1e-12);
  CHECK_NEAR(scribe_detail::loop8_bytes("abababababababababab"), 11.0 / 13.0, 1e-12);
  CHECK(scribe_detail::utf8_valid("caf\xC3\xA9") && !scribe_detail::utf8_valid("caf\xC3") && !scribe_detail::utf8_valid("\xC0\x80"));
  ScribeModel m;
  m.train({"The cat sat on the mat. The dog sat on the log. A cat saw a dog.", "The dog saw the cat. The mat was red. A log was on the mat."}, 1);
  const std::uint32_t the = m.word_id("the"), cat = m.word_id("cat"), dog = m.word_id("dog");
  CHECK(the != ScribeModel::kUnk && cat != ScribeModel::kUnk && m.word_id("zebra") == ScribeModel::kUnk);
  const std::uint32_t ctxs[][2] = {{ScribeModel::kBos, ScribeModel::kBos}, {the, cat}, {cat, dog}, {the, the}, {dog, ScribeModel::kUnk}};
  for (const auto& cx : ctxs) {
    double s = 0;
    for (std::uint32_t w = 0; w < m.vocab_size(); ++w) s += std::exp(m.logp(cx[0], cx[1], w));
    CHECK_NEAR(s, 1.0, 1e-9);
  }
  CHECK(m.logp(the, cat, m.word_id("sat")) > m.logp(the, cat, m.word_id("red")));
  WordDict dict;
  const Features ok = extract_features(m, dict, "The cat sat on the mat. The dog saw the cat.");
  const Features bad = extract_features(m, dict, "the cat (sat on");
  CHECK_NEAR(ok.s1, 1.0, 1e-12);
  CHECK_NEAR(ok.s4, 1.0, 1e-12);
  CHECK(ok.has_c && ok.n_sent == 2 && ok.n_words == 11);
  CHECK_NEAR(bad.s4, 2.0 / 6.0, 1e-12);
  CHECK_NEAR(ok.d[0], 7.0 / 11.0, 1e-12);
  const Features rep = extract_features(m, dict, "The cat sat. The cat sat. The cat sat.");
  CHECK_NEAR(rep.rep, 2.0 / 3.0, 1e-12);
  SurfaceRef sr;
  surface_add_vocab(sr, "the quick brown fox jumps over the lazy dog and the cat");
  CHECK(surface_S(sr, "the quick brown fox jumps over the lazy dog and the cat") > surface_S(sr, "zzz qqq xxx zzz qqq xxx zzz qqq xxx zzz qqq xxx"));
  {
    const std::vector<std::vector<float>> U = {{1, 0, 0}, {1, 0, 0}, {0, 1, 0}};
    CHECK_NEAR(scribe_detail::mean_pairwise_cosine(U), 1.0 / 3.0, 1e-9);
    CHECK_NEAR(scribe_detail::mean_pairwise_cosine({{1, 0}, {0, 1}}), 0.0, 1e-9);
  }
  {
    WordVectors wv;
    wv.set({"aa", "bb", "cc", "dd"}, {1000, 100, 10, 1}, {1, 0.2f, 0, 1, 0.1f, 0, 0.9f, 0.3f, 0, 0, 1, 0.2f}, 3);
    for (int i = 0; i < 4; ++i) {
      double n2 = 0;
      for (int k = 0; k < 3; ++k) n2 += double(wv.row(i)[k]) * wv.row(i)[k];
      CHECK_NEAR(n2, 1.0, 1e-5);
    }
    CHECK(wv.index("cc") == 2 && wv.index("zz") == -1 && wv.dim() == 3 && wv.size() == 4);
    std::stringstream vs(std::ios::in | std::ios::out | std::ios::binary), ts;
    const float rw[6] = {1, 0, 0, 0, 1, 0};
    vs.write(reinterpret_cast<const char*>(rw), sizeof rw);
    ts << "the\t100\nof\t50\n";
    WordVectors w2;
    CHECK(w2.load_streams(vs, ts, 3) && w2.size() == 2 && w2.index("of") == 1);
    SentenceEmbedder se(&wv);
    std::vector<float> va, vb;
    CHECK(se.raw({"aa", "dd"}, va) && !se.raw({"aa", "zz"}, vb, 2) && se.raw({"aa", "zz"}, vb, 1));
  }
  {
    Features f;
    f.sent_len = {5, 5, 5, 5};
    std::vector<double> pmf(kMaxLen + 1, 0.0);
    pmf[5] = 0.5;
    pmf[10] = 0.5;
    CHECK_NEAR(ks_lengths({&f}, pmf), 0.5, 1e-12);
  }
  {
    const std::string g = clean_generated_text(
        " of the [[city]] was large. It has ''many'' old [[Rome|buildings]] and wide squares.\n\nAnother sentence here is fine. The next one is cu");
    CHECK(g == "It has many old buildings and wide squares. Another sentence here is fine.");
    CHECK(clean_generated_text("no terminator at all here") == "terminator at all");
  }
  // ---- tool-level checks ----------------------------------------------------------------
  {
    const std::string line = "{\"id\":\"a\\\"b\",\"n\":3.5,\"meta\":{\"x\":[1,{\"y\":\"}\"}]},\"text\":\"caf\\u00e9 \\ud83d\\ude00\\nz\",\"t\":true}";
    JsonObj o;
    CHECK(JsonReader(line).object(o));
    CHECK(o.get("id") == "a\"b" && o.num.count("n") && o.num.at("n") == 3.5);
    CHECK(o.get("text") == "caf\xC3\xA9 \xF0\x9F\x98\x80\nz");
    JsonObj o2;
    CHECK(JsonReader("{\"text\":\"" + json_escape(std::string("q\"\\\n\x01 \xC3")) + "\"}").object(o2));
    CHECK(o2.get("text") == std::string("q\"\\\n\x01 \xEF\xBF\xBD"));  // the invalid byte became U+FFFD
    JsonObj o3;
    CHECK(!JsonReader("{\"a\":\"unterminated}").object(o3));
  }
  {
    CHECK(prepare_continuation("  It was a dark night.\nThe rain fell on the  town. And then the") == "It was a dark night. The rain fell on the town.");
    CHECK(prepare_continuation("no boundary at all") == "no boundary at all");
    CHECK(prepare_continuation("He said \"stop.\" Then he left") == "He said \"stop.\"");
  }
  {
    std::mt19937_64 r(1);
    const std::string t = "The cat sat on the mat. The dog saw the cat. A red mat was on the log.";
    CHECK(split_sentences(ctl_shuffle_words(t, r)).size() == 3);
    CHECK(ctl_repeat_phrase(t).size() >= t.size());
  }
  {
    std::string t;
    for (int i = 0; i < 30; ++i) t += "This is sentence number " + std::to_string(i) + " of a long story here. ";
    const std::vector<std::string> ws = text_windows(t);
    std::size_t total = 0;
    bool ok = !ws.empty();
    for (const std::string& w : ws) {
      total += w.size();
      ok = ok && w.size() >= 300 && w.size() <= 900;
    }
    CHECK(ok && ws.size() >= 2 && total + ws.size() - 1 == scribe_detail::collapse_ws(t).size());
    CHECK(text_windows("Short text. Only two sentences.").size() == 1);
  }
  // ---- v3.1's near-duplicate filter: a document that repeats a pack document is dropped, a new one is kept ----
  {
    std::string page;
    for (int i = 0; i < 6; ++i) page += "The river Avon rises near the village of Naseby and flows west through the county of Warwickshire. ";
    std::vector<std::string> test = {page + "A short new ending.", "An entirely new document about the orbit of a small comet, written for this check, which shares no long string."};
    std::size_t bytes = 0;
    const std::vector<char> dup = near_duplicates(test, {page}, {"An unrelated reference document."}, &bytes);
    CHECK(dup.size() == 2 && dup[0] && !dup[1] && bytes == test[0].size());
    std::vector<std::string> t2 = test;
    const std::string note = apply_dedup(t2, {page}, {});
    CHECK(t2.size() == 1 && t2[0] == test[1] && note.find("dropped 1 of 2") != std::string::npos);
  }
  // ---- v3.1's held-out attacks: construction only, on toy strings (they are never run on development data) ----
  {
    const std::string t = "a1 a2 a3 a4 a5 a6 a7 a8 a9 a10 a11 a12 a13 a14 a15.";
    CHECK(stuff_keywords(t, {"K"}) == "a1 a2 a3 a4 K a5 a6 a7 a8 K a9 a10 a11 a12 K a13 a14 a15.");  // the registered rate is unchanged
    CHECK(stuff_keywords(t, {"K", "L"}, 7) == "a1 a2 a3 a4 a5 a6 a7 K a8 a9 a10 a11 a12 a13 a14 L a15.");
    CHECK(stuff_keywords("a b c d e f g", {"K"}, 3) == "a b c K d e f K g");
    std::mt19937_64 r(3);
    const std::vector<std::string> sr = split_ws(stuff_random(t, {"K"}, r));
    std::vector<std::string> kept;
    std::size_t nk = 0, gap = 0, mingap = 99, maxgap = 0;
    for (const std::string& w : sr) {
      if (w == "K") {
        ++nk;
        mingap = std::min(mingap, gap);
        maxgap = std::max(maxgap, gap);
        gap = 0;
      } else {
        kept.push_back(w);
        ++gap;
      }
    }
    CHECK(join(kept) == t && nk >= 1 && nk <= 7 && mingap >= 2 && maxgap <= 8 && sr.back() != "K");
    auto rar = [](const std::string& w) { return static_cast<double>(w.size()); };  // toy rarity: longer is rarer
    auto con = [](const std::string& w) { return w != "the" && w != "and"; };
    CHECK((prompt_keywords_by("The Paris sewers and the catacombs of Paris.", rar, con) == std::vector<std::string>{"catacombs", "sewers", "Paris"}));
    CHECK((prompt_keywords_by("The Paris sewers and the catacombs of Paris.", rar, con, false) == std::vector<std::string>{"Paris", "sewers", "catacombs"}));
    CHECK((prompt_keywords_by("The Paris sewers and the catacombs of Paris.", rar, con, true, true) == std::vector<std::string>{"catacombs", "sewers"}));
    CHECK((text_entities("The city of Paris is in France. Paris has a river named Seine, and the Seine is long.") ==
           std::vector<std::string>{"Seine", "Paris", "France"}));
    const std::string tt = template_text({"Paris", "France"}, {"catacombs", "sewers"});
    CHECK(tt.rfind("Paris is one of", 0) == 0 && tt.find("linked with France") != std::string::npos && tt.find("with catacombs") != std::string::npos &&
          tt.find("role in sewers") != std::string::npos && split_sentences(tt).size() == 5 && tt.back() == '.');
    CHECK(template_text({}, {}).rfind("History is one of", 0) == 0);
    CHECK(echo_scatter("P one. P two.", "C one. C two. C three.") == "C one. P one. C two. P two. C three. P one.");
    CHECK(echo_scatter("", "C one. C two.") == "C one. C two.");
    CHECK(title_swap("Smith went home. Later Smith slept, and Smith's dog too.", "Today Jones arrived.") ==
          "Jones went home. Later Jones slept, and Smith's dog too.");
    CHECK(title_swap("no names here at all.", "Today Jones arrived.") == "no names here at all.");
    const std::vector<std::pair<int, std::string>> pool = {
        {1, "The catacombs lie under the city of old."}, {2, "A cat sat on a mat in the sun all day long."}, {3, "The sewers were built long ago."},
        {1, "The catacombs and the sewers meet."}, {4, "Its sewers drain into the river."}, {0, "The catacombs of Paris hold bones."}};
    const std::string lr = list_related("Paris sewers and the catacombs.", 0, pool, rar, con);
    CHECK(lr == "The catacombs and the sewers meet. The sewers were built long ago. Its sewers drain into the river.");
  }
  scribe_v2_selftest(g_checks, g_fail);
  scribe_v3_selftest(g_checks, g_fail);
  std::printf("scribe selftest: %d checks, %d failed\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    std::fprintf(stderr,
                 "usage: scribe <docs|prompts|samples|prepare|ladder|score|attacks|dedup|windows|selftest> ...  (see the header of native/tools/eval/scribe.cpp)\n");
    return 2;
  }
  const std::string cmd = argv[1];
  if (cmd == "selftest" || cmd == "--selftest") return selftest();
  const Args a = parse_args(argc, argv, 2);
  if (cmd == "docs") return cmd_docs(a);
  if (cmd == "prompts") return cmd_prompts(a);
  if (cmd == "samples") return cmd_samples(a);
  if (cmd == "prepare") return cmd_prepare(a);
  if (cmd == "ladder") return cmd_ladder(a);
  if (cmd == "score") return cmd_score(a);
  if (cmd == "windows") return cmd_windows(a);
  if (cmd == "attacks") return cmd_attacks(a);
  if (cmd == "dedup") return cmd_dedup(a);
  std::fprintf(stderr, "unknown subcommand %s\n", cmd.c_str());
  return 2;
}
